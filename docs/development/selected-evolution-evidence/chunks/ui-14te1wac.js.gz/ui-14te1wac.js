import {
  defineUI,
  netLogoColor,
  Agent,
  Random,
  World,
  Grid,
  stats,
  parameters,
  stepCount
} from "./app-shg8ggtp.js";

// experiments/mimicry/model.ts
var sourceMarker = "B08-mimicry-native-composition-v1";
function colorInMemory(memory, color) {
  return memory.some((entry) => entry[0] === color);
}
function rememberColor(memory, color, size) {
  if (size === 0 && memory.length === 0)
    throw new RangeError("Source but-first received an empty memory.");
  const retained = memory.length >= size ? memory.slice(1) : memory;
  return [
    ...retained.map(([c, age]) => [c, age]),
    [color, 0]
  ];
}
function forgetColors(memory, duration) {
  return memory.map(([color, age]) => [color, age + 1]).filter((entry) => entry[1] <= duration);
}
var inputs = {
  seed: { kind: "number", default: 1, integer: true },
  memoryDuration: {
    kind: "number",
    default: 30,
    min: 0,
    max: 40,
    integer: true
  },
  mutationRate: { kind: "number", default: 5, min: 0, max: 100 },
  memorySize: { kind: "number", default: 3, min: 0, max: 10, integer: true }
};
function create(options = {}) {
  let settings = parameters(inputs, options);
  const random = Random.add({ seed: settings.seed });
  const world = World.add({ x: 41, y: 41, boundary: "wrap" }, { random });
  const grid = Grid.add(world.space);
  world.add(grid);
  const history = [];
  function population(breed) {
    const all = world.agents;
    return breed === undefined ? all : all.filter((a) => a.breed === breed);
  }
  function setup() {
    world.delete(world.agents);
    world.tick.reset();
    random.reseed(settings.seed);
    for (const [breed, count, color] of [
      ["bird", 75, 0],
      ["monarch", 225, 15],
      ["viceroy", 225, 105]
    ]) {
      for (let i = 0;i < count; i++) {
        world.add(Agent.add({ breed, color, memory: [] }, {
          position: {
            x: random.number() * 41 - 20.5,
            y: random.number() * 41 - 20.5
          },
          orientation: {
            heading: random.number({ max: 360, integer: true })
          }
        }));
      }
    }
    history.length = 0;
    record();
  }
  function record() {
    history.push({
      tick: world.tick.value,
      monarchs: population("monarch").length,
      viceroys: population("viceroy").length,
      monarchMeanColor: stats.describe(population("monarch").map((a) => a.color)).mean,
      viceroyMeanColor: stats.describe(population("viceroy").map((a) => a.color)).mean
    });
    if (history.length > 1001)
      history.splice(1, 1);
  }
  function birdsMove() {
    for (const bird of random.sample(population("bird"), {
      count: population("bird").length,
      compatibility: "legacy-shuffle"
    })) {
      bird.rotate(180 + random.number({ max: 180, integer: true }) - bird.heading);
      bird.move(1);
    }
  }
  function butterfliesMove() {
    const butterflies = population().filter((a) => a.breed !== "bird");
    for (const butterfly of random.sample(butterflies, {
      count: butterflies.length,
      compatibility: "legacy-shuffle"
    })) {
      butterfly.rotate(random.number({ max: 100, integer: true }));
      butterfly.rotate(-random.number({ max: 100, integer: true }));
      butterfly.move(1);
    }
  }
  function butterfliesGetEaten() {
    const butterflies = population().filter((a) => a.breed !== "bird");
    for (const butterfly of random.sample(butterflies, {
      count: butterflies.length,
      compatibility: "legacy-shuffle"
    })) {
      const patch = grid.fieldAt(butterfly);
      const birds = grid.agentsAt(patch, { source: population("bird") });
      const bird = random.sample(birds)[0];
      if (bird && !colorInMemory(bird.memory, butterfly.color)) {
        if (butterfly.breed === "monarch")
          bird.memory = rememberColor(bird.memory, butterfly.color, settings.memorySize);
        butterfly.delete();
      }
    }
  }
  function birdsForget() {
    const birds = population("bird");
    for (const bird of random.sample(birds, {
      count: birds.length,
      compatibility: "legacy-shuffle"
    }))
      bird.memory = forgetColors(bird.memory, settings.memoryDuration);
  }
  function butterfliesReproduce() {
    const butterflies = population().filter((a) => a.breed !== "bird");
    for (const butterfly of random.sample(butterflies, {
      count: butterflies.length,
      compatibility: "legacy-shuffle"
    })) {
      const count = population(butterfly.breed).length;
      if (random.number({ max: count, integer: true }) < 225 - count && random.number() * 100 < 4) {
        const child = butterfly.copy();
        world.add(child);
        child.move(1);
        if (random.number() * 100 < settings.mutationRate)
          child.color = random.sample([15, 25, 35, 45, 55, 65, 75, 85, 95])[0];
      }
    }
  }
  function advance(count = 1) {
    stepCount(count);
    for (let i = 0;i < count; i++) {
      birdsMove();
      butterfliesMove();
      butterfliesGetEaten();
      birdsForget();
      butterfliesReproduce();
      world.tick.advance();
      record();
    }
  }
  function read() {
    const snapshots = population().map((a) => ({
      id: a.id,
      x: a.x,
      y: a.y,
      heading: a.heading,
      color: a.color,
      breed: a.breed,
      memory: a.memory.map((entry) => [...entry])
    }));
    return {
      sourceMarker,
      tick: world.tick.value,
      width: 41,
      height: 41,
      parameters: settings,
      monarchColor: stats.describe(population("monarch").map((a) => a.color)),
      viceroyColor: stats.describe(population("viceroy").map((a) => a.color)),
      birds: snapshots.filter((a) => a.breed === "bird"),
      monarchs: snapshots.filter((a) => a.breed === "monarch"),
      viceroys: snapshots.filter((a) => a.breed === "viceroy"),
      history: history.map((p) => ({ ...p })),
      randomState: random.state
    };
  }
  setup();
  return {
    setup,
    advance,
    read,
    birdsMove,
    butterfliesMove,
    butterfliesGetEaten,
    birdsForget,
    butterfliesReproduce,
    setParameters(update) {
      settings = parameters(inputs, { ...settings, ...update });
    }
  };
}
var model = { title: "Mimicry", inputs, create };

// experiments/mimicry/ui.ts
var ui = defineUI(model, {
  setup: [{ field: "seed" }],
  live: ["memoryDuration", "mutationRate", "memorySize"].map((field) => ({
    field,
    value: (s) => s.parameters[field],
    set: (m, value) => m.setParameters({ [field]: Number(value) })
  })),
  source: {
    url: "https://www.netlogoweb.org/launch#https://www.netlogoweb.org/assets/modelslib/Sample%20Models/Biology/Evolution/Mimicry.nlogox",
    label: "NetLogo Mimicry · Wilensky · CC BY-NC-SA 3.0"
  },
  monitors: [
    { label: "Tick", value: (s) => s.tick },
    { label: "Monarchs", value: (s) => s.monarchs.length },
    { label: "Viceroys", value: (s) => s.viceroys.length },
    ...["monarchColor", "viceroyColor"].flatMap((group) => ["min", "mean", "max"].map((metric) => ({
      label: `${group === "monarchColor" ? "Monarch color" : "Viceroy color"} ${metric}`,
      value: (s) => s[group][metric] ?? "N/A"
    })))
  ],
  views: [
    {
      type: "spatial",
      label: "Birds and butterflies",
      data: (s) => ({
        width: s.width,
        height: s.height,
        agents: [...s.monarchs, ...s.viceroys, ...s.birds].map((a) => ({
          ...a,
          color: a.breed === "bird" ? "#666666" : netLogoColor(a.color),
          size: a.breed === "bird" ? 7 : 5,
          shape: a.breed === "bird" ? "triangle" : "circle"
        }))
      })
    },
    {
      type: "line",
      label: "Butterfly populations",
      series: (s) => ["monarchs", "viceroys"].map((key) => ({
        label: key === "monarchs" ? "Monarchs" : "Viceroys",
        color: key === "monarchs" ? "#d73027" : "#4575b4",
        points: s.history.map((p) => ({ x: p.tick, y: p[key] }))
      }))
    },
    {
      type: "line",
      label: "Mean butterfly colors",
      series: (s) => ["monarchMeanColor", "viceroyMeanColor"].map((key) => ({
        label: key === "monarchMeanColor" ? "Monarchs" : "Viceroys",
        color: key === "monarchMeanColor" ? "#d73027" : "#4575b4",
        points: s.history.flatMap((p) => p[key] === undefined ? [] : [{ x: p.tick, y: p[key] }])
      }))
    },
    {
      type: "inspector",
      label: "Bird memory",
      value: (s, id) => {
        const a = [...s.birds, ...s.monarchs, ...s.viceroys].find((a) => a.id === id);
        return a ? { breed: a.breed, color: a.color, memory: JSON.stringify(a.memory) } : undefined;
      }
    }
  ]
});
export {
  ui
};
