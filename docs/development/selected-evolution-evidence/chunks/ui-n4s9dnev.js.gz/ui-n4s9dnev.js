import {
  defineUI,
  Agent,
  Random,
  World,
  Grid,
  parameters,
  stepCount
} from "./app-shg8ggtp.js";
// experiments/mammoths/data/terrain.json
var terrain_default = {
  sourceSha256: "8473b9d79835f81c88cd266049789fb83db4dd218c3402730d8526d3df6f824c",
  command: "random-seed 1 setup",
  bounds: [
    0,
    96,
    0,
    96
  ],
  wrapX: false,
  wrapY: false,
  orientation: "row-major y ascending0..96 then x ascending0..96; first row is south/bottom",
  rows: [
    "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000000111110000000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000011111000000000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000011110000000000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000111110000000000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000111111100000000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000111111100000000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000111111000000000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000011111110000000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000011111110000000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000011111111100000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000011111111111000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000001111111111110000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000001111111111110000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000001111111111110000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000000111111111111100000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000000111111111111110000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000000111111111111111000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000000111111111111111100000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000000111111111111111110000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000000011111111111111110000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000000011111111111111110000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000000011111111111111111100000000",
    "0000000000000000000000000000000000000000000000000000000000000000000000011111111111111111111100000",
    "0000000000000000000000000000000000000000000000000000000000000000000000011111111111111111111110000",
    "0000000000000000000000000000000000000000000000000000000000000000000000011111111111111111111111000",
    "0000000000000000000000000000000000000000000000000000000000000000000000011111111111111111111111000",
    "0000000000000000000000000000000000000000000000000000000000000000000000111111111111111111111111000",
    "0000000000000000000000000000000000000000000000000000000000000000000011111111111111111111111111000",
    "0000000000000000000000000000000000000000000000000000000000000000000111111111111111111111111111000",
    "0000000000000000000000000000000000000000000000000000000000000000001111111111111111111111111111100",
    "0000000000000000000000000000000000000000000000000000000000000000001111111111111111111111111111100",
    "0000000000000000000000000000000000000000000000000000000000000000011111111111111111111111111111111",
    "0000000000000000000000000000000000000000000000000000000000000000011111111111111111111111111111111",
    "0000000000000000000000000000000000000000000000000000000000000000111111111111111111111111111111111",
    "0000000000000000000000000000000000000000000000000000000000000000111111111111111111111111111111111",
    "0000000000000000000000000000000000000000000000000000000000000001111111111111111111111111111111110",
    "0000000000000000000000000000000000000000000000000000000000000000111111111111111111111111111111000",
    "0000000000000000000000000000000000000000000000000000000000000000111111111111111111111101111010000",
    "0000000000000000000000000000000000000000000000000000000000000001111111111111111111110111000000000",
    "0000000000000000000000000000000000000000000000000000000000000000111111111111111111111100000000000",
    "0000000000000000000000000000000000000000000000000000000000000000011111111111111111111100000000000",
    "0000000000000000000000000000000000000000000000000000000000000000011111111111111111111000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000001111111111111111110000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000011111111111111111000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000011011111111111111100000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000111111111111111110000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000011100100111011101111000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000011100000011100000000000000000000000000",
    "0000000000000000000000000000000000000000000000000000000010111100000000000000000000000000000000000",
    "0000000000000000000000000000000000000000000000000000001111111100000000000000000000000000000000000",
    "0000000000000000000000000000000000000000000000000101111111011000000000000000000000000000000000000",
    "0000000000000000000000000000000000000000000000001111111111000000000000000000000000000000000000000",
    "0000000000000000000000000000000000000000000000011111101111100000000000000000000000000000000000000",
    "0000000000000000000000000000000000000000000000111111000011100000000000000000000000000000000000000",
    "0000000000000000000000000000000000000000000001111111000011100000000000000000000000000000000000000",
    "0000000000000000000000000000000000000000001001111110000000000000000000000000000000000000000000000",
    "0000000000000000000000000000000000000000111011111110000000000000000000000000000000000000000000000",
    "0000000000000000000000000000000000000000110111111111000000000001000000000000000000000000000000000",
    "0000000000000000000000000000000000000011111111111111000000000011000000000000000000000000000000000",
    "0000000000000000000000000000000000000011111111111111100010000011000000000000000000000000000000000",
    "0000000000000000000000000000000000000111111111111111111111101110000000000000000000000000000000000",
    "0000000000000000000000000000000000000110111111111111111111111110000000000000000000000000000000000",
    "0000000000000000000000000000000000001111111111111111111111111111000000000000000000000000000000000",
    "0000000000000000000000000000000000001111111111111111111111111111110000000000000000000000000000000",
    "0000000000000000000000000000000000111111111111111111111111111111111000000000000000000000000000000",
    "0000000000000000000000000000000001111111111111111111111111111111111000000000000000000000000000000",
    "0000000000000000000000000000000011111111111111111111111111111111111100000000000000000000000000000",
    "0000000000000000000000000000000011111111111111111111111111111111111110000000000000000000000000000",
    "0000000000000000000000000000000011111111111111111111111111111111111111100000000000000000000000000",
    "0000000000000000000000000000000011111111111111111111111111111111111111100000000000000000000000000",
    "0000000000000000000000000000000111111111111111111111111111101101001111111011100000000000000000000",
    "0000000000000000000000000000000011111111111111111111111111111111111111111111111000000000000000000",
    "0000000000000000000000000000000111111111111111111111111111110010111111111111101000000000000000000",
    "0000000000000000000000000000000111111111111111111111111111111111111111111111000111110000000000000",
    "0000000000000000000000000000011101111111111111111111111111001111111111111100110011100000000000000",
    "0000000000000000000000000000111111111111111111111111111111111111111111111111111010000000000000000",
    "0000000000000000000000000010111111111111111111111111111111111111011111111111111111000000000000000",
    "0000000000000000000000000111111111111111111111111111111111111111111111111111111111000000000000000",
    "0001110000000000000000000111111111111111111111111111111111111100111111111111111110000000000000000",
    "0000011100100000000000001111111111111111111111111111111111101000001111111111110000000000000000000",
    "0000001111110000000000011111111111111111111111111111111100000000001111111111110000000000000000000",
    "0000111111100000000001111111111111111111111111111111111000000000011111110011000000000000000000000",
    "0011111111111110111111111111111111111111111111111111110000000000001111110001000000000000000000000",
    "0111111111111111111111111111111111111111111111111111111000000000011111100000000000000000000000000",
    "0011111111111111111111111111111111111111111111111111111110000011000001111111000000000000000000000",
    "0111111111111111111111111111111111111111111111111111111111111110011111111101100000000000000000000",
    "1111111111111111111111111111111111111111111111111111111111111000010011111111110000000000000000000",
    "0010111111111111111111111111111111111111111111111111111111111111001101111111010000000000000000000",
    "0111111111111111111111111111111111111111111111000001101111001100001111111000000000000000000000000",
    "0001111111111111111001011001110111001111111111111000001101111111111111111000000000000000000000000",
    "0000000111100000000000000000000011101111111111110000011011111111111111010000000000000000000000000",
    "0000000000000000000000000000000111111111111011100000000011111111111000000000000000000000000000000",
    "0000000000000000000000000000000111111110000011000000000000010001100000000000000000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
  ],
  landCount: 2505,
  maskSha256: "939f62e8e2ba22565d2515ffa35dbd73338eeaf0cc98ec70fcdf8c75919f9fd6",
  postImportColorsSha256: "5522d3646dbbc1f7b02d66ff1a6db207f9398e8e2a1df331b24cf52f42929642",
  setupColorsSha256: "20bbf46861dd5a0cf1823b496466fed366c9282bc43914f39e03667733c620b0",
  patchCount: 9409,
  tick: {
    success: true,
    value: 0
  },
  globals: {
    success: true,
    value: [
      900,
      50,
      0,
      0
    ]
  }
};

// experiments/mammoths/model.ts
var sourceMarker = "B08-mammoths-native-mask-composition-v1";
var inputs = {
  seed: { kind: "number", default: 1, integer: true },
  numberOfMammoths: {
    kind: "number",
    default: 900,
    min: 0,
    max: 2000,
    integer: true
  },
  numberOfHumans: {
    kind: "number",
    default: 50,
    min: 0,
    max: 100,
    integer: true
  },
  mammothBirthRate: { kind: "number", default: 2, min: 0, max: 10 },
  humanBirthRate: { kind: "number", default: 10, min: 0, max: 20 },
  mammothSpeed: { kind: "number", default: 0.2, min: 0, max: 1 },
  humanSpeed: { kind: "number", default: 0.3, min: 0, max: 1 },
  oddsOfKilling: { kind: "number", default: 12, min: 1, max: 97 },
  climateChangeDecayChance: {
    kind: "number",
    default: 0.003,
    min: 0,
    max: 100
  }
};
function create(options = {}) {
  let settings = parameters(inputs, options);
  const random = Random.add({ seed: settings.seed });
  const world = World.add({ x: 97, y: 97, boundary: "hard" }, { random });
  const grid = Grid.add(world.space, {
    state: { terrain: "ocean" }
  });
  world.add(grid);
  let mammothsKilledByHumans = 0;
  let mammothsKilledByClimateChange = 0;
  const history = [];
  const population = (breed) => world.agents.filter((a) => breed === undefined || a.breed === breed);
  function record() {
    history.push({
      tick: world.tick.value,
      mammoths: population("mammoth").length,
      humans: population("human").length,
      hunting: mammothsKilledByHumans,
      climate: mammothsKilledByClimateChange
    });
    if (history.length > 1001)
      history.splice(1, 1);
  }
  function setup() {
    world.delete(world.agents);
    world.tick.reset();
    random.reseed(settings.seed);
    history.length = 0;
    mammothsKilledByHumans = 0;
    mammothsKilledByClimateChange = 0;
    for (const field of grid.fields)
      field.terrain = terrain_default.rows[field.y + 48][field.x + 48] === "1" ? "land" : "ocean";
    for (const breed of ["mammoth", "human"]) {
      const count = breed === "mammoth" ? settings.numberOfMammoths : settings.numberOfHumans;
      const eligible = grid.fields.filter((field) => field.terrain === "land" && (breed === "mammoth" || field.x + 48 <= 10));
      for (let i = 0;i < count; i++) {
        const field = random.sample(eligible)[0];
        world.add(Agent.add({
          breed,
          age: random.number({
            max: (breed === "mammoth" ? 30 : 50) * 12,
            integer: true
          }),
          settled: false
        }, {
          position: { x: field.x, y: field.y },
          orientation: {
            heading: breed === "human" ? -5 + random.number({ max: 10, integer: true }) : random.number({ max: 360, integer: true })
          }
        }));
      }
    }
    record();
  }
  function landAhead(resident, distance) {
    const angle = resident.heading * Math.PI / 180;
    const patch = grid.fieldAt({
      x: resident.x + distance * Math.sin(angle),
      y: resident.y + distance * Math.cos(angle)
    });
    return patch !== undefined && patch.terrain !== "ocean";
  }
  function move(resident, distance) {
    resident.rotate(random.number({ max: 30, integer: true }));
    resident.rotate(-random.number({ max: 30, integer: true }));
    const turn = random.sample([-10, 10])[0];
    let attempts = 0;
    while (!landAhead(resident, distance)) {
      resident.rotate(turn);
      if (++attempts >= 36)
        throw new RangeError("No land-ahead heading in one complete source turning cycle.");
    }
    resident.move(distance);
  }
  function reproduce(resident, minAge, birthRate) {
    if (resident.age >= minAge && random.number({ max: 100, integer: true }) < birthRate) {
      const child = resident.copy();
      world.add(child);
      child.age = 0;
      if (child.breed === "human")
        child.settled = false;
    }
  }
  function density(resident) {
    const here = grid.fieldAt(resident);
    const patches = [here, ...grid.neighbors(here, { neighborhood: "moore" })];
    return population(resident.breed).filter((a) => patches.includes(grid.fieldAt(a))).length / 9;
  }
  function climateChange() {
    const land = grid.fields.filter((field) => field.terrain === "land");
    for (const field of random.sample(land, {
      count: land.length,
      compatibility: "legacy-shuffle"
    })) {
      if (random.number() * 100 < settings.climateChangeDecayChance)
        field.terrain = "changed";
    }
  }
  function mammothsAct() {
    const mammoths = population("mammoth");
    for (const mammoth of random.sample(mammoths, {
      count: mammoths.length,
      compatibility: "legacy-shuffle"
    })) {
      move(mammoth, settings.mammothSpeed);
      reproduce(mammoth, 3 * 12, settings.mammothBirthRate);
    }
  }
  function humansAct() {
    const humans = population("human");
    for (const human of random.sample(humans, {
      count: humans.length,
      compatibility: "legacy-shuffle"
    })) {
      const nearby = human.neighbors({
        source: population("mammoth"),
        radius: 5
      });
      if (!human.settled && random.number({ max: 100, integer: true }) < nearby.length)
        human.settled = true;
      if (!human.settled) {
        if (nearby.length) {
          const shuffled = random.sample(nearby, {
            count: nearby.length,
            compatibility: "legacy-shuffle"
          });
          shuffled.sort((a, b) => human.distanceTo(a) - human.distanceTo(b));
          human.rotate({ towards: shuffled[0] });
        }
        move(human, settings.humanSpeed);
      }
      const mammothsHere = grid.agentsAt(grid.fieldAt(human), {
        source: population("mammoth")
      });
      if (mammothsHere.length) {
        const r = random.number({ max: 100, integer: true });
        if (r < 3) {
          human.delete();
          continue;
        }
        if (r < 3 + settings.oddsOfKilling) {
          random.sample(mammothsHere)[0].delete();
          mammothsKilledByHumans++;
        }
      }
      reproduce(human, 12 * 12, settings.humanBirthRate);
    }
  }
  function dieNaturally() {
    for (const breed of ["human", "mammoth"]) {
      const group = population(breed);
      for (const resident of random.sample(group, {
        count: group.length,
        compatibility: "legacy-shuffle"
      })) {
        if (resident.age > (breed === "human" ? 50 : 30) * 12 && random.number() * 100 < 5) {
          resident.delete();
          continue;
        }
        if (density(resident) > (breed === "human" ? 0.75 : 0.5) && random.number() * 100 < 5) {
          resident.delete();
          continue;
        }
        if (breed === "mammoth" && grid.fieldAt(resident).terrain === "changed" && random.number() * 100 < 5) {
          mammothsKilledByClimateChange++;
          resident.delete();
          continue;
        }
        if (random.number() * 100 < 0.33)
          resident.delete();
      }
    }
  }
  function advance(count = 1) {
    stepCount(count);
    for (let i = 0;i < count; i++) {
      climateChange();
      mammothsAct();
      humansAct();
      dieNaturally();
      for (const resident of population())
        resident.age++;
      world.tick.advance();
      record();
    }
  }
  function read() {
    const agents = population().map((a) => ({
      id: a.id,
      x: a.x,
      y: a.y,
      originalX: a.x + 48,
      originalY: a.y + 48,
      heading: a.heading,
      age: a.age,
      settled: a.settled,
      breed: a.breed
    }));
    return {
      sourceMarker,
      tick: world.tick.value,
      width: 97,
      height: 97,
      years: world.tick.value / 12,
      parameters: settings,
      mammothsKilledByHumans,
      mammothsKilledByClimateChange,
      mammoths: agents.filter((a) => a.breed === "mammoth"),
      humans: agents.filter((a) => a.breed === "human"),
      cells: grid.fields.map((field) => ({
        id: field.id,
        x: field.x,
        y: field.y,
        originalX: field.x + 48,
        originalY: field.y + 48,
        terrain: field.terrain
      })),
      history: history.map((p) => ({ ...p })),
      randomState: random.state
    };
  }
  setup();
  return {
    setup,
    advance,
    read,
    landAhead,
    move,
    reproduce,
    density,
    climateChange,
    mammothsAct,
    humansAct,
    dieNaturally,
    setParameters(update) {
      settings = parameters(inputs, { ...settings, ...update });
    }
  };
}
var model = { title: "Mammoths", inputs, create };

// experiments/mammoths/ui.ts
var ui = defineUI(model, {
  setup: [
    { field: "seed" },
    { field: "numberOfMammoths" },
    { field: "numberOfHumans" }
  ],
  live: [
    "mammothBirthRate",
    "humanBirthRate",
    "mammothSpeed",
    "humanSpeed",
    "oddsOfKilling",
    "climateChangeDecayChance"
  ].map((field) => ({
    field,
    value: (s) => s.parameters[field],
    set: (m, value) => m.setParameters({ [field]: Number(value) })
  })),
  source: {
    url: "https://www.netlogoweb.org/launch#https://www.netlogoweb.org/assets/modelslib/Sample%20Models/Biology/Evolution/Mammoths.nlogox",
    label: "NetLogo Mammoths · Wilensky · CC BY-NC-SA 3.0"
  },
  monitors: [
    { label: "Months", value: (s) => s.tick },
    { label: "Years", value: (s) => s.years },
    { label: "Mammoths", value: (s) => s.mammoths.length },
    { label: "Humans", value: (s) => s.humans.length },
    { label: "Hunting deaths", value: (s) => s.mammothsKilledByHumans },
    { label: "Climate deaths", value: (s) => s.mammothsKilledByClimateChange }
  ],
  views: [
    {
      type: "spatial",
      label: "Americas habitat",
      data: (s) => ({
        width: s.width,
        height: s.height,
        cells: s.cells.map((c) => ({
          ...c,
          color: c.terrain === "ocean" ? "#245eaa" : c.terrain === "changed" ? "#a7d67c" : "#329b32"
        })),
        agents: [
          ...s.mammoths.map((a) => ({ ...a, color: "#8c541f", size: 5 })),
          ...s.humans.map((a) => ({ ...a, color: "#ffdf00", size: 4 }))
        ]
      })
    },
    {
      type: "line",
      label: "Populations",
      series: (s) => ["mammoths", "humans"].map((key) => ({
        label: key,
        color: key === "mammoths" ? "#8c541f" : "#b8a600",
        points: s.history.map((p) => ({ x: p.tick, y: p[key] }))
      }))
    },
    {
      type: "line",
      label: "Cause of mammoth deaths",
      series: (s) => ["hunting", "climate"].map((key) => ({
        label: key,
        color: key === "hunting" ? "#b8a600" : "#329b32",
        points: s.history.map((p) => ({ x: p.tick, y: p[key] }))
      }))
    },
    {
      type: "inspector",
      label: "Resident",
      value: (s, id) => {
        const a = [...s.mammoths, ...s.humans].find((a) => a.id === id);
        return a ? {
          breed: a.breed,
          ageMonths: a.age,
          settled: a.settled,
          sourceX: a.originalX,
          sourceY: a.originalY
        } : undefined;
      }
    }
  ]
});
export {
  ui
};
