import {
  defineUI,
  Agent,
  Random,
  World,
  Grid,
  stats,
  geometry,
  parameters,
  stepCount
} from "./app-shg8ggtp.js";

// experiments/vision-evolution/model.ts
var sourceMarker = "b08-vision-evolution-source-composition-v1";
var inputs = {
  seed: {
    kind: "number",
    default: 1,
    min: -2147483648,
    max: 4294967295,
    integer: true
  },
  initialNumberFish: {
    kind: "number",
    default: 50,
    min: 0,
    max: 250,
    integer: true
  },
  initialNumberFood: {
    kind: "number",
    default: 80,
    min: 0,
    max: 250,
    integer: true
  },
  energyGainFromFood: {
    kind: "number",
    default: 100,
    min: 0,
    max: 300,
    integer: true
  },
  foodReplenishRate: {
    kind: "number",
    default: 65,
    min: 0,
    max: 100,
    integer: true
  },
  mutationRate: { kind: "number", default: 0.1, min: 0, max: 1, step: 0.01 },
  reproductionRate: {
    kind: "number",
    default: 35,
    min: 0,
    max: 100,
    integer: true
  },
  eyeCost: { kind: "number", default: 9, min: 0, max: 10, step: 0.1 },
  showVision: { kind: "boolean", default: true },
  maxEyeSize: { kind: "number", default: 5, min: 1, max: 10, integer: true }
};
function visionRadius(eyeSize, y, maxEyeSize) {
  return y < 0 ? eyeSize / maxEyeSize + 3 : eyeSize ** 2 + 3;
}
function energyCost(eyeSize, landMobility, y, eyeCost) {
  return Math.abs((y < 0 ? landMobility : 1 - landMobility) * 10 - 0.5) + Math.abs((eyeSize - 1) / (11 - eyeCost));
}
function weightedDistance(distance, preyY, preference) {
  return distance * Math.exp((preyY < 0 ? preference - 0.5 : 0.5 - preference) * 3);
}
function create(options = {}) {
  let settings = parameters(inputs, options);
  const random = Random.add({ seed: settings.seed });
  const space = {
    x: 101,
    y: 101,
    boundary: { x: "wrap", y: "hard" }
  };
  const world = World.add(space, { random });
  const grid = Grid.add(space);
  world.add(grid);
  const fish = () => world.agents.filter((a) => a.breed === "fish");
  const food = () => world.agents.filter((a) => a.breed === "food");
  const history = [];
  function makeFood() {
    const prey = Agent.add({ breed: "food" }, {
      position: {
        x: random.number() * 101 - 50.5,
        y: random.number() * 101 - 50.5
      },
      orientation: {
        heading: random.number({ min: 0, max: 360, integer: true })
      }
    });
    world.add(prey);
    return prey;
  }
  function makeFish(state = {}) {
    const agent = Agent.add({
      breed: "fish",
      eyeSize: state.eyeSize ?? 1,
      landMobility: state.landMobility ?? 0,
      landFoodPreference: state.landFoodPreference ?? random.number(),
      energy: state.energy ?? random.number() * 2 * settings.energyGainFromFood,
      fovRadius: 0
    }, {
      position: {
        x: state.x ?? random.number() * 101 - 50.5,
        y: state.y ?? -random.number({ min: 0, max: 50, integer: true })
      },
      orientation: {
        heading: state.heading ?? random.number({ min: 0, max: 360, integer: true })
      }
    });
    world.add(agent);
    agent.fovRadius = visionRadius(agent.eyeSize, agent.y, settings.maxEyeSize);
    return agent;
  }
  function setup() {
    world.delete(world.agents);
    world.tick.reset();
    history.length = 0;
    for (let n = 0;n < settings.initialNumberFood; n++)
      makeFood();
    for (let n = 0;n < settings.initialNumberFish; n++)
      makeFish();
    record();
  }
  function mutate(value, rate, lower, upper) {
    return Math.max(lower, Math.min(upper, value + random.number() * 2 * rate - rate));
  }
  function move(agent) {
    const step = (agent.y < 0 ? 1 - agent.landMobility : agent.landMobility) + random.number() * 0.1;
    const radius = visionRadius(agent.eyeSize, agent.y, settings.maxEyeSize);
    const visible = agent.neighbors({ source: food(), radius });
    const distances = visible.map((prey) => ({
      prey,
      distance: weightedDistance(agent.distanceTo(prey), prey.y, agent.landFoodPreference)
    }));
    const minimum = Math.min(...distances.map((p) => p.distance));
    const prey = random.sample(distances.filter((p) => p.distance === minimum))[0]?.prey;
    if (prey) {
      agent.rotate({ towards: prey });
      if (agent.distanceTo(prey) < step)
        agent.move({ to: prey });
      else
        agent.move(step);
    } else {
      agent.rotate(random.number({ min: 0, max: 50, integer: true }));
      agent.rotate(-random.number({ min: 0, max: 50, integer: true }));
      const direction = geometry.direction({ heading: agent.heading });
      const ahead = geometry.normalize({ x: agent.x + direction.x * step, y: agent.y + direction.y * step }, { space, endpoints: "half-open" });
      if (!ahead)
        agent.rotate(-random.number() * 180);
      agent.move(step);
    }
    agent.fovRadius = radius;
  }
  function consumeEnergy(agent) {
    agent.energy -= energyCost(agent.eyeSize, agent.landMobility, agent.y, settings.eyeCost);
  }
  function eatFood(agent) {
    const prey = random.sample(grid.agentsAt(grid.fieldAt(agent), { source: food() }))[0];
    if (prey) {
      prey.delete();
      agent.energy += settings.energyGainFromFood;
    }
  }
  function death(agent) {
    if (agent.energy < 0)
      agent.delete();
  }
  function reproduce(agent) {
    if (random.number({ min: 0, max: 100, integer: true }) >= settings.reproductionRate || agent.energy <= 100 / settings.reproductionRate * settings.energyGainFromFood)
      return;
    agent.energy /= 2;
    const child = agent.copy();
    child.eyeSize = mutate(child.eyeSize, settings.mutationRate * 3, 1, settings.maxEyeSize);
    child.landMobility = mutate(child.landMobility, settings.mutationRate, 0, 1);
    child.landFoodPreference = mutate(child.landFoodPreference, settings.mutationRate, 0, 1);
    child.fovRadius = visionRadius(child.eyeSize, child.y, settings.maxEyeSize);
    world.add(child);
    move(agent);
  }
  function replenishFood() {
    if (random.number({ min: 0, max: 100, integer: true }) < settings.foodReplenishRate)
      makeFood();
  }
  function record() {
    history.push({
      tick: world.tick.value,
      fish: fish().length,
      food: food().length,
      terrestrialEye: stats.describe(fish().filter((a) => a.landMobility >= 0.5).map((a) => a.eyeSize)).mean ?? 1,
      aquaticEye: stats.describe(fish().filter((a) => a.landMobility < 0.5).map((a) => a.eyeSize)).mean ?? 1
    });
    if (history.length > 1001)
      history.splice(1, 1);
  }
  function advance(steps = 1) {
    stepCount(steps);
    for (let n = 0;n < steps; n++) {
      if (!fish().length)
        break;
      for (const agent of random.sample(fish(), {
        count: fish().length,
        compatibility: "legacy-shuffle"
      })) {
        move(agent);
        consumeEnergy(agent);
        eatFood(agent);
        death(agent);
        if (agent.alive)
          reproduce(agent);
      }
      replenishFood();
      world.tick.advance();
      record();
    }
  }
  function read() {
    return {
      sourceMarker,
      parameters: { ...settings },
      randomState: random.state,
      width: 101,
      height: 101,
      tick: world.tick.value,
      done: !fish().length,
      fish: fish().map((a) => ({
        id: a.id,
        x: a.x,
        y: a.y,
        heading: a.heading,
        eyeSize: a.eyeSize,
        landMobility: a.landMobility,
        landFoodPreference: a.landFoodPreference,
        energy: a.energy,
        fovRadius: a.fovRadius
      })),
      food: food().map((a) => ({ id: a.id, x: a.x, y: a.y })),
      cells: grid.fields.map((f) => ({
        id: f.id,
        x: f.x,
        y: f.y,
        water: f.y <= 0
      })),
      eyeSizeHistogram: stats.histogram(fish().map((a) => a.eyeSize), {
        edges: Array.from({ length: 11 }, (_, i) => 1 + i * (Math.max(1.000001, settings.maxEyeSize) - 1) / 10)
      }),
      landMobilityHistogram: stats.histogram(fish().map((a) => a.landMobility), { edges: Array.from({ length: 11 }, (_, i) => i / 10) }),
      foodPreferenceHistogram: stats.histogram(fish().map((a) => a.landFoodPreference), { edges: Array.from({ length: 11 }, (_, i) => i / 10) }),
      history: history.map((p) => ({ ...p }))
    };
  }
  function setParameters(change) {
    settings = parameters(inputs, { ...settings, ...change });
  }
  setup();
  return {
    read,
    advance,
    setup,
    setParameters,
    makeFood,
    makeFish,
    move,
    consumeEnergy,
    eatFood,
    death,
    reproduce,
    replenishFood,
    mutate
  };
}
var model = {
  title: "Vision Evolution",
  inputs,
  create
};

// experiments/vision-evolution/ui.ts
var ui = defineUI(model, {
  setup: [
    { field: "seed" },
    { field: "initialNumberFish" },
    { field: "initialNumberFood" }
  ],
  live: [
    "energyGainFromFood",
    "foodReplenishRate",
    "mutationRate",
    "reproductionRate",
    "eyeCost",
    "maxEyeSize",
    "showVision"
  ].map((field) => ({
    field,
    value: (s) => s.parameters[field],
    set: (m, v) => m.setParameters({
      [field]: field === "showVision" ? Boolean(v) : Number(v)
    })
  })),
  source: {
    url: "https://www.netlogoweb.org/launch#https://www.netlogoweb.org/assets/modelslib/Sample%20Models/Biology/Evolution/Vision%20Evolution.nlogox",
    label: "NetLogo original · Wilensky · CC BY-NC-SA 3.0"
  },
  complete: (s) => s.done,
  monitors: [
    { label: "Tick", value: (s) => s.tick },
    { label: "Fish", value: (s) => s.fish.length },
    { label: "Food", value: (s) => s.food.length }
  ],
  views: [
    {
      type: "spatial",
      label: "Water, land and vision",
      data: (s) => ({
        width: s.width,
        height: s.height,
        cells: s.cells.map((c) => ({
          ...c,
          color: c.water ? "#264e91" : "#8b603f"
        })),
        agents: [
          ...s.parameters.showVision ? s.fish.map((a) => ({
            id: `fov-${a.id}`,
            x: a.x,
            y: a.y,
            color: "#9b9b9b32",
            size: a.fovRadius * 6
          })) : [],
          ...s.food.map((a) => ({ ...a, color: "#000000", size: 4 })),
          ...s.fish.map((a) => ({
            ...a,
            color: `hsl(0 70% ${35 + a.landMobility * 35}%)`,
            shape: "triangle",
            size: 12
          }))
        ]
      })
    },
    {
      type: "line",
      label: "Population size",
      series: (s) => [
        {
          label: "Fish",
          color: "#ce4747",
          points: s.history.map((p) => ({ x: p.tick, y: p.fish }))
        },
        {
          label: "Food",
          color: "#333333",
          points: s.history.map((p) => ({ x: p.tick, y: p.food }))
        }
      ]
    },
    {
      type: "line",
      label: "Average eye size",
      series: (s) => [
        {
          label: "Terrestrial",
          color: "#ce4747",
          points: s.history.map((p) => ({ x: p.tick, y: p.terrestrialEye }))
        },
        {
          label: "Aquatic",
          color: "#428bd0",
          points: s.history.map((p) => ({ x: p.tick, y: p.aquaticEye }))
        }
      ]
    },
    ...[
      "eyeSizeHistogram",
      "landMobilityHistogram",
      "foodPreferenceHistogram"
    ].map((key, i) => ({
      type: "bar",
      label: [
        "Eye size histogram",
        "Land mobility histogram",
        "Food preference histogram"
      ][i],
      series: (s) => [
        {
          label: "Fish",
          points: s[key].counts.map((y, index) => ({
            x: s[key].edges[index],
            y
          }))
        }
      ]
    })),
    {
      type: "inspector",
      label: "Selected fish",
      value: (s, id) => s.fish.find((a) => a.id === id)
    }
  ]
});
export {
  ui
};
