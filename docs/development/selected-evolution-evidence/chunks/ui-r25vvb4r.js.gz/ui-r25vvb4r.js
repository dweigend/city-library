import {
  defineUI,
  netLogoColor,
  Agent,
  Random,
  World,
  Grid,
  stats,
  parameters,
  stepCount
} from "./app-shg8ggtp.js";

// experiments/anisogamy/model.ts
var sourceMarker = "B08-anisogamy-native-composition-v1";
function gameteDiameter(mass) {
  return 2 * Math.sqrt(mass / Math.PI);
}
function tickAdvanceAmount(diameters) {
  return diameters.length ? Math.min(...diameters) / gameteDiameter(0.5) : 1;
}
var inputs = {
  seed: { kind: "number", default: 1, integer: true },
  maxAdults: { kind: "number", default: 100, min: 10, max: 500, integer: true },
  worldSize: { kind: "number", default: 65, min: 1, max: 97, integer: true },
  zygoteFitnessThreshold: { kind: "number", default: 0.45, min: 0, max: 0.5 },
  gameteFitnessThreshold: { kind: "number", default: 0, min: 0, max: 0.51 },
  mutationSigma: { kind: "number", default: 0.025, min: 0, max: 0.1 },
  speedSizeCorrelation: { kind: "boolean", default: false },
  allowAssortativeFusion: { kind: "boolean", default: false }
};
function create(options = {}) {
  let settings = parameters(inputs, options);
  const random = Random.add({ seed: settings.seed });
  let world = World.add({ x: settings.worldSize, y: settings.worldSize, boundary: "wrap" }, { random });
  let grid = Grid.add(world.space, { state: { color: 89 } });
  world.add(grid);
  const history = [];
  let delta = 1;
  let wholeTick = false;
  const population = (breed) => world.agents.filter((a) => breed === undefined || a.breed === breed);
  function record() {
    history.push({
      tick: world.tick.value,
      adults: population("adult").length,
      gametes: population("gamete").length,
      zygotes: population("zygote").length,
      blueAdults: population("adult").filter((a) => a.matingTypeTrait === 105).length,
      redAdults: population("adult").filter((a) => a.matingTypeTrait === 15).length,
      blueGametes: population("gamete").filter((a) => a.matingTypeTrait === 105).length,
      redGametes: population("gamete").filter((a) => a.matingTypeTrait === 15).length,
      blueMeanTrait: stats.describe(population("adult").filter((a) => a.matingTypeTrait === 105).map((a) => a.gameteSizeTrait)).mean,
      redMeanTrait: stats.describe(population("adult").filter((a) => a.matingTypeTrait === 15).map((a) => a.gameteSizeTrait)).mean
    });
    if (history.length > 1001)
      history.splice(1, 1);
  }
  function setup() {
    world.delete(world.agents);
    if (world.space.x !== settings.worldSize) {
      world = World.add({ x: settings.worldSize, y: settings.worldSize, boundary: "wrap" }, { random });
      grid = Grid.add(world.space, { state: { color: 89 } });
      world.add(grid);
    }
    world.tick.reset();
    random.reseed(settings.seed);
    delta = 1;
    wholeTick = false;
    history.length = 0;
    for (const field of random.sample(grid.fields, {
      count: grid.fields.length,
      compatibility: "legacy-shuffle"
    })) {
      field.color = 89 + random.number() - random.number() * 2;
    }
    for (let i = 0;i < 10; i++)
      grid.diffuse("color", { rate: 0.5, neighborhood: "moore" });
    for (let i = 0;i < settings.maxAdults; i++) {
      random.number({ max: 14, integer: true });
      world.add(Agent.add({
        breed: "adult",
        matingTypeTrait: 0,
        gameteSizeTrait: 0.25,
        life: 0,
        size: 1,
        speed: 0,
        incubationTime: 0
      }, {
        orientation: {
          heading: random.number({ max: 360, integer: true })
        }
      }));
    }
    const adults = population("adult");
    for (const adult of random.sample(adults, {
      count: adults.length,
      compatibility: "legacy-shuffle"
    })) {
      adult.move({
        to: {
          x: random.number() * settings.worldSize - settings.worldSize / 2,
          y: random.number() * settings.worldSize - settings.worldSize / 2
        }
      });
      adult.matingTypeTrait = random.sample([15, 105])[0];
      adult.life = random.number({
        distribution: "normal",
        mean: 500,
        deviation: 50
      });
    }
    record();
  }
  function produceGametes(adult) {
    const mass = random.number({
      distribution: "normal",
      mean: adult.gameteSizeTrait,
      deviation: settings.mutationSigma
    });
    if (mass < settings.gameteFitnessThreshold)
      return;
    if (mass === 0)
      throw new RangeError("Source division by zero in provisioning budget / instantaneous gamete size.");
    const count = Math.floor(0.5 / mass);
    for (let i = 0;i < count; i++) {
      const child = adult.copy();
      world.add(child);
      child.breed = "gamete";
      child.gameteSizeTrait = mass;
      child.size = gameteDiameter(mass);
      child.life = random.number({
        distribution: "normal",
        mean: 50,
        deviation: 5
      });
      child.speed = settings.speedSizeCorrelation ? gameteDiameter(0.5) / child.size : 1;
    }
  }
  function becomeAdult(zygote) {
    zygote.breed = "adult";
    zygote.size = 1;
    zygote.life = random.number({
      distribution: "normal",
      mean: 500,
      deviation: 50
    });
  }
  function enforceCarryingCapacity() {
    const adults = population("adult");
    if (adults.length > settings.maxAdults) {
      for (const adult of random.sample(adults, {
        count: adults.length - settings.maxAdults
      }))
        adult.delete();
    }
  }
  function fuseIfTouchingAnotherGamete(gamete) {
    const here = grid.fieldAt(gamete);
    const patches = [here, ...grid.neighbors(here, { neighborhood: "moore" })];
    const candidates = population("gamete").filter((other) => other !== gamete && patches.includes(grid.fieldAt(other)) && gamete.distanceTo(other) < (gamete.size + other.size) / 2 && (settings.allowAssortativeFusion || other.matingTypeTrait !== gamete.matingTypeTrait));
    if (!candidates.length)
      return;
    const partner = random.sample(candidates)[0];
    const mass = gamete.gameteSizeTrait + partner.gameteSizeTrait;
    const inherited = random.sample([gamete, partner])[0];
    if (mass >= settings.zygoteFitnessThreshold) {
      const child = gamete.copy();
      world.add(child);
      child.breed = "zygote";
      child.gameteSizeTrait = inherited.gameteSizeTrait;
      child.matingTypeTrait = inherited.matingTypeTrait;
      child.size = gameteDiameter(mass);
      child.incubationTime = random.number({
        distribution: "normal",
        mean: 100,
        deviation: 10
      });
    }
    partner.delete();
    gamete.delete();
  }
  function advance(count = 1) {
    stepCount(count);
    for (let i = 0;i < count; i++) {
      wholeTick = Math.floor(world.tick.value) > Math.floor(world.tick.value - delta);
      if (wholeTick) {
        const adults = population("adult");
        for (const adult of random.sample(adults, {
          count: adults.length,
          compatibility: "legacy-shuffle"
        })) {
          adult.rotate(random.number() * 360 - adult.heading);
          adult.move(1);
          if (random.number() * 100 < 1.5)
            produceGametes(adult);
          adult.life--;
          if (adult.life < 1)
            adult.delete();
        }
        const zygotes = population("zygote");
        for (const zygote of random.sample(zygotes, {
          count: zygotes.length,
          compatibility: "legacy-shuffle"
        })) {
          zygote.incubationTime--;
          if (zygote.incubationTime < 1)
            becomeAdult(zygote);
        }
        enforceCarryingCapacity();
      }
      if (settings.speedSizeCorrelation)
        delta = tickAdvanceAmount(population("gamete").map((a) => a.size));
      const gametes = population("gamete");
      for (const gamete of random.sample(gametes, {
        count: gametes.length,
        compatibility: "legacy-shuffle"
      })) {
        if (!gamete.alive)
          continue;
        gamete.rotate(random.number({ max: 360, integer: true }) - gamete.heading);
        gamete.move(gamete.speed * delta);
        fuseIfTouchingAnotherGamete(gamete);
        if (gamete.alive) {
          gamete.life -= delta;
          if (gamete.life <= 0)
            gamete.delete();
        }
      }
      world.tick.advance(delta);
      record();
      if (!population().length)
        break;
    }
  }
  function read() {
    const agents = population().map((a) => ({
      id: a.id,
      x: a.x,
      y: a.y,
      heading: a.heading,
      breed: a.breed,
      matingTypeTrait: a.matingTypeTrait,
      gameteSizeTrait: a.gameteSizeTrait,
      life: a.life,
      size: a.size,
      speed: a.speed,
      incubationTime: a.incubationTime
    }));
    return {
      sourceMarker,
      tick: world.tick.value,
      width: world.space.x,
      height: world.space.y,
      tickAdvanceAmount: delta,
      wholeTick,
      done: !agents.length,
      parameters: settings,
      cells: grid.fields.map((f) => ({
        id: f.id,
        x: f.x,
        y: f.y,
        color: f.color
      })),
      traitDistribution: {
        blue: stats.histogram(population("adult").filter((a) => a.matingTypeTrait === 105).map((a) => a.gameteSizeTrait), { edges: Array.from({ length: 21 }, (_, i) => i / 40) }),
        red: stats.histogram(population("adult").filter((a) => a.matingTypeTrait === 15).map((a) => a.gameteSizeTrait), { edges: Array.from({ length: 21 }, (_, i) => i / 40) })
      },
      adults: agents.filter((a) => a.breed === "adult"),
      gametes: agents.filter((a) => a.breed === "gamete"),
      zygotes: agents.filter((a) => a.breed === "zygote"),
      history: history.map((p) => ({ ...p })),
      randomState: random.state
    };
  }
  function setParameters(update) {
    settings = parameters(inputs, { ...settings, ...update });
  }
  function restoreDefaultParameters() {
    setParameters({
      worldSize: 65,
      maxAdults: 100,
      zygoteFitnessThreshold: 0.45,
      gameteFitnessThreshold: 0.01,
      mutationSigma: 0.025,
      speedSizeCorrelation: false,
      allowAssortativeFusion: false
    });
  }
  setup();
  return {
    setup,
    advance,
    read,
    setParameters,
    restoreDefaultParameters,
    produceGametes,
    becomeAdult,
    enforceCarryingCapacity,
    fuseIfTouchingAnotherGamete
  };
}
var model = {
  title: "Anisogamy",
  inputs,
  create
};

// experiments/anisogamy/ui.ts
var ui = defineUI(model, {
  setup: [{ field: "seed" }],
  live: [
    "worldSize",
    "maxAdults",
    "zygoteFitnessThreshold",
    "gameteFitnessThreshold",
    "mutationSigma",
    "speedSizeCorrelation",
    "allowAssortativeFusion"
  ].map((field) => ({
    field,
    value: (s) => s.parameters[field],
    set: (m, value) => m.setParameters({
      [field]: field === "speedSizeCorrelation" || field === "allowAssortativeFusion" ? Boolean(value) : Number(value)
    })
  })),
  actions: [
    {
      label: "Restore default parameters",
      run: (m) => m.restoreDefaultParameters()
    }
  ],
  complete: (s) => s.done,
  source: {
    url: "https://www.netlogoweb.org/launch#https://www.netlogoweb.org/assets/modelslib/Sample%20Models/Biology/Evolution/Anisogamy.nlogox",
    label: "NetLogo Anisogamy · Wilensky · CC BY-NC-SA 3.0"
  },
  monitors: [
    { label: "Tick", value: (s) => s.tick },
    { label: "Adults", value: (s) => s.adults.length },
    { label: "Gametes", value: (s) => s.gametes.length },
    { label: "Zygotes", value: (s) => s.zygotes.length },
    { label: "Tick advance", value: (s) => s.tickAdvanceAmount }
  ],
  views: [
    {
      type: "spatial",
      label: "Adults, gametes and zygotes",
      data: (s) => ({
        width: s.width,
        height: s.height,
        cells: s.cells.map((c) => ({ ...c, color: netLogoColor(c.color) })),
        agents: [...s.adults, ...s.gametes, ...s.zygotes].map((a) => ({
          ...a,
          color: netLogoColor(a.matingTypeTrait + (a.breed === "adult" ? 1 : a.breed === "gamete" ? -1 : 3)),
          size: a.breed === "gamete" ? Math.max(2, a.size * 8) : a.breed === "zygote" ? 5 : 7
        }))
      })
    },
    {
      type: "line",
      label: "Adult mating types",
      series: (s) => ["blueAdults", "redAdults"].map((key) => ({
        label: key,
        color: key === "blueAdults" ? "#4575b4" : "#d73027",
        points: s.history.map((p) => ({ x: p.tick, y: p[key] }))
      }))
    },
    {
      type: "line",
      label: "Gamete mating types",
      series: (s) => ["blueGametes", "redGametes"].map((key) => ({
        label: key,
        color: key === "blueGametes" ? "#4575b4" : "#d73027",
        points: s.history.map((p) => ({ x: p.tick, y: p[key] }))
      }))
    },
    {
      type: "line",
      label: "Mean gamete mass trait",
      series: (s) => ["blueMeanTrait", "redMeanTrait"].map((key) => ({
        label: key,
        color: key === "blueMeanTrait" ? "#4575b4" : "#d73027",
        points: s.history.flatMap((p) => p[key] === undefined ? [] : [{ x: p.tick, y: p[key] }])
      }))
    },
    {
      type: "bar",
      label: "Adult gamete mass traits",
      series: (s) => ["blue", "red"].map((key) => ({
        label: key,
        color: key === "blue" ? "#4575b4" : "#d73027",
        points: s.traitDistribution[key].counts.map((count, i) => ({
          x: s.traitDistribution[key].edges[i],
          y: count
        }))
      }))
    },
    {
      type: "inspector",
      label: "Inherited strategy",
      value: (s, id) => {
        const a = [...s.adults, ...s.gametes, ...s.zygotes].find((a) => a.id === id);
        return a ? {
          breed: a.breed,
          matingType: a.matingTypeTrait,
          massTrait: a.gameteSizeTrait,
          life: a.life,
          incubationTime: a.incubationTime
        } : undefined;
      }
    }
  ]
});
export {
  ui
};
