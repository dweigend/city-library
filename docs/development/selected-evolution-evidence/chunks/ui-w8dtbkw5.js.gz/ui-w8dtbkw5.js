import {
  defineUI,
  netLogoColor,
  Agent,
  Random,
  World,
  Grid,
  stats,
  geometry,
  parameters,
  stepCount
} from "./app-shg8ggtp.js";

// experiments/gendrift-t-interact/model.ts
var sourceMarker = "b08-gendrift-t-interact-source-composition-v1";
var inputs = {
  seed: {
    kind: "number",
    default: 1,
    integer: true,
    min: -2147483648,
    max: 4294967295
  },
  number: { kind: "number", default: 300, min: 1, max: 1000, integer: true },
  colors: { kind: "number", default: 5, min: 2, max: 10, integer: true }
};
var sourceColors = [5, 15, 25, 35, 45, 55, 65, 85, 95, 125];
function create(options = {}) {
  let settings = parameters(inputs, options);
  const random = Random.add({ seed: settings.seed });
  const space = { x: 35, y: 35, boundary: "wrap" };
  const world = World.add(space, { random });
  const grid = Grid.add(space, { state: { wall: false } });
  world.add(grid);
  const turtles = () => world.agents;
  let maxPercent = 0;
  let wallMode = "place";
  const history = [];
  function moveOffWall(turtle) {
    if (!grid.fields.some((f) => !f.wall))
      throw new RangeError("No open patch: source move-off-wall would not terminate.");
    while (grid.fieldAt(turtle).wall) {
      const field = random.sample(grid.neighbors(grid.fieldAt(turtle), { neighborhood: "moore" }))[0];
      turtle.move({ to: field });
    }
  }
  function makeTurtle(colorNumber, x, y, heading = 0) {
    if (!sourceColors.includes(colorNumber))
      throw new RangeError("Unknown source turtle color.");
    const turtle = Agent.add({ colorNumber }, { position: { x, y }, orientation: { heading } });
    world.add(turtle);
    moveOffWall(turtle);
    return turtle;
  }
  function setup() {
    world.delete(turtles());
    world.tick.reset();
    history.length = 0;
    for (let n = 0;n < settings.number; n++) {
      const turtle = Agent.add({
        colorNumber: sourceColors[random.number({ min: 0, max: settings.colors, integer: true })]
      }, {
        position: {
          x: random.number() * 35 - 17.5,
          y: random.number() * 35 - 17.5
        },
        orientation: {
          heading: random.number({ min: 0, max: 360, integer: true })
        }
      });
      world.add(turtle);
      moveOffWall(turtle);
    }
    record();
  }
  function record() {
    history.push({
      tick: world.tick.value,
      counts: [5, 15, 25, 35, 45, 55, 65, 75, 85, 95].map((c) => turtles().filter((t) => t.colorNumber === c).length)
    });
    if (history.length > 1001)
      history.splice(1, 1);
  }
  function meet(turtle) {
    const target = grid.fieldAt(geometry.normalize({ x: turtle.x + 1, y: turtle.y }, { space, endpoints: "half-open" }));
    const other = random.sample(grid.agentsAt(target, { source: turtles() }))[0];
    if (other)
      turtle.colorNumber = other.colorNumber;
  }
  function placeWall(row) {
    if (!Number.isFinite(row) || Math.round(row) < -17 || Math.round(row) > 17)
      throw new RangeError("Wall row is outside source bounds.");
    for (const field of grid.fields) {
      if (Math.abs(field.y) === 17 || field.y === Math.round(row)) {
        field.wall = true;
        for (const turtle of grid.agentsAt(field, { source: turtles() }))
          moveOffWall(turtle);
      }
    }
  }
  function removeWall(row) {
    if (!Number.isFinite(row))
      throw new TypeError("Wall row must be finite.");
    for (const field of grid.fields)
      if (field.y === Math.round(row))
        field.wall = false;
  }
  function removeAllWalls() {
    for (const field of grid.fields)
      field.wall = false;
  }
  function setWallMode(value) {
    wallMode = value;
  }
  function drawWall(row) {
    if (wallMode === "place")
      placeWall(row);
    else
      removeWall(row);
  }
  function advance(steps = 1) {
    stepCount(steps);
    for (let n = 0;n < steps; n++) {
      if (stats.describe(turtles().map((a) => a.colorNumber)).variance === 0)
        break;
      for (const turtle of random.sample(turtles(), {
        count: turtles().length,
        compatibility: "legacy-shuffle"
      })) {
        turtle.rotate(random.number({ min: 0, max: 50, integer: true }) - random.number({ min: 0, max: 50, integer: true }));
        meet(turtle);
        const direction = geometry.direction({ heading: turtle.heading });
        const ahead = geometry.normalize({ x: turtle.x + direction.x * 0.5, y: turtle.y + direction.y * 0.5 }, { space, endpoints: "half-open" });
        if (!grid.fieldAt(ahead).wall)
          turtle.move(0.5);
        else
          turtle.rotate(random.number({ min: 0, max: 360, integer: true }));
      }
      maxPercent = 100 * Math.max(...sourceColors.map((c) => turtles().filter((a) => a.colorNumber === c).length)) / turtles().length;
      world.tick.advance();
      record();
    }
  }
  function read() {
    return {
      sourceMarker,
      parameters: { ...settings },
      randomState: random.state,
      width: 35,
      height: 35,
      tick: world.tick.value,
      maxPercent,
      wallMode,
      done: stats.describe(turtles().map((a) => a.colorNumber)).variance === 0,
      cells: grid.fields.map((f) => ({
        id: f.id,
        x: f.x,
        y: f.y,
        wall: f.wall
      })),
      turtles: turtles().map((a) => ({
        id: a.id,
        x: a.x,
        y: a.y,
        heading: a.heading,
        colorNumber: a.colorNumber
      })),
      history: history.map((p) => ({ ...p, counts: [...p.counts] }))
    };
  }
  function setParameters(change) {
    settings = parameters(inputs, { ...settings, ...change });
  }
  setup();
  return {
    read,
    advance,
    setup,
    setParameters,
    placeWall,
    removeWall,
    removeAllWalls,
    setWallMode,
    drawWall,
    makeTurtle,
    meet,
    moveOffWall
  };
}
var model = {
  title: "GenDrift T interact",
  inputs,
  create
};

// experiments/gendrift-t-interact/ui.ts
var ui = defineUI(model, {
  setup: [{ field: "seed" }, { field: "number" }, { field: "colors" }],
  actions: [
    { label: "Setup preserving walls", run: (m) => m.setup() },
    {
      label: "Place walls",
      run: (m) => m.setWallMode("place"),
      pressed: (s) => s.wallMode === "place"
    },
    {
      label: "Remove walls",
      run: (m) => m.setWallMode("remove"),
      pressed: (s) => s.wallMode === "remove"
    },
    { label: "Remove all walls", run: (m) => m.removeAllWalls() }
  ],
  drawing: {
    toggleLabel: "Draw walls",
    enabled: () => true,
    intent: (m, intent) => {
      if (intent.phase !== "end")
        m.drawWall(intent.position.y);
    }
  },
  source: {
    url: "https://www.netlogoweb.org/launch#https://www.netlogoweb.org/assets/modelslib/Sample%20Models/Biology/Evolution/Genetic%20Drift/GenDrift%20T%20interact.nlogox",
    label: "NetLogo original · Wilensky · CC BY-NC-SA 3.0"
  },
  complete: (s) => s.done,
  monitors: [
    { label: "Tick", value: (s) => s.tick },
    {
      label: "Most populous (%)",
      value: (s) => Number(s.maxPercent.toFixed(2))
    }
  ],
  views: [
    {
      type: "spatial",
      label: "Genetic drift and walls",
      data: (s) => ({
        width: s.width,
        height: s.height,
        cells: s.cells.map((c) => ({
          ...c,
          color: c.wall ? "#ffffff" : "#000000"
        })),
        agents: s.turtles.map((a) => ({
          ...a,
          color: netLogoColor(a.colorNumber),
          size: 6,
          shape: "triangle"
        }))
      })
    },
    {
      type: "line",
      label: "Turtle populations",
      series: (s) => [5, 15, 25, 35, 45, 55, 65, 125, 85, 95].map((c, i) => ({
        label: `Color ${c}`,
        color: netLogoColor(c),
        points: s.history.map((p) => ({ x: p.tick, y: p.counts[i] }))
      }))
    },
    {
      type: "inspector",
      label: "Selected turtle",
      value: (s, id) => s.turtles.find((a) => a.id === id)
    }
  ]
});
export {
  ui
};
