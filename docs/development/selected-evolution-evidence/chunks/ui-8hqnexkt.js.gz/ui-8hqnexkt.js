import {
  defineUI,
  Agent,
  Random,
  World,
  stats,
  parameters,
  stepCount
} from "./app-shg8ggtp.js";

// experiments/sex-ratio-equilibrium/model.ts
var sourceMarker = "b08-sex-ratio-equilibrium-source-composition-v1";
var inputs = {
  seed: {
    kind: "number",
    default: 1,
    min: -2147483648,
    max: 4294967295,
    integer: true
  },
  initialPopulationSize: {
    kind: "number",
    default: 500,
    min: 0,
    max: 1000,
    integer: true
  },
  initialAdultSexRatio: {
    kind: "number",
    default: 35,
    min: 0,
    max: 100,
    integer: true
  },
  initialAverageMaleChildChance: {
    kind: "number",
    default: 0.4,
    min: 0,
    max: 1,
    step: 0.01
  },
  meanLongevity: { kind: "number", default: 60, min: 0, max: 150, step: 5 },
  gestationPeriod: {
    kind: "number",
    default: 5,
    min: 0,
    max: 20,
    integer: true
  },
  maximumLitterSize: {
    kind: "number",
    default: 6,
    min: 1,
    max: 10,
    integer: true
  },
  matingChance: { kind: "number", default: 0.85, min: 0, max: 1, step: 0.05 }
};
function adultSexRatio(population) {
  const adults = population.filter((a) => a.adult).length;
  return adults ? population.filter((a) => a.sex === "male").length / adults * 100 : 0;
}
function create(options = {}) {
  let settings = parameters(inputs, options);
  const random = Random.add({ seed: settings.seed });
  const world = World.add({ x: 33, y: 21, boundary: "wrap" }, { random });
  const population = () => world.agents;
  const males = () => population().filter((a) => a.sex === "male");
  const females = () => population().filter((a) => a.sex === "female");
  let adultAge = Math.trunc(0.15 * settings.meanLongevity);
  const adultSexRatioHistory = [];
  const ageList = [];
  const history = [];
  function makeIndividual(sex, parent) {
    const mean = parent ? parent.tempMaleChildChance : settings.initialAverageMaleChildChance;
    const chance = Math.max(0, Math.min(1, random.number({ distribution: "normal", mean, deviation: 0.05 })));
    const agent = Agent.add({
      sex,
      partner: null,
      carrying: false,
      maleChildChance: chance,
      tempMaleChildChance: 0,
      gestation: 0,
      age: parent ? 0 : Math.trunc(random.number({
        distribution: "normal",
        mean: settings.meanLongevity / 2,
        deviation: settings.meanLongevity / 10
      })),
      longevity: Math.trunc(random.number({
        distribution: "normal",
        mean: settings.meanLongevity,
        deviation: settings.meanLongevity / 10
      })),
      numOfExes: 0,
      numOfChildren: 0,
      adult: parent?.adult ?? true
    }, {
      position: parent ? { x: parent.x, y: parent.y } : { x: random.number() * 33 - 16.5, y: random.number() * 21 - 10.5 },
      orientation: {
        heading: random.number({ min: 0, max: 360, integer: true })
      }
    });
    world.add(agent);
    return agent;
  }
  function setup() {
    world.delete(population());
    world.tick.reset();
    adultSexRatioHistory.length = 0;
    ageList.length = 0;
    history.length = 0;
    adultAge = Math.trunc(0.15 * settings.meanLongevity);
    const count = Math.round(settings.initialAdultSexRatio / 100 * settings.initialPopulationSize);
    for (let n = 0;n < count; n++)
      makeIndividual("male");
    for (let n = count;n < settings.initialPopulationSize; n++)
      makeIndividual("female");
    record();
  }
  function move(individual) {
    individual.rotate(random.number({ min: 0, max: 60, integer: true }));
    individual.rotate(-random.number({ min: 0, max: 60, integer: true }));
    individual.move(0.1);
  }
  function checkIfDead(individual) {
    if (individual.age > individual.longevity) {
      ageList.push(individual.age);
      for (const other of population())
        if (other.partner === individual)
          other.partner = null;
      individual.delete();
    } else
      individual.age++;
  }
  function searchForAnAdultPartner(male) {
    const eligibleFemales = male.neighbors({
      source: females().filter((a) => a.adult && !a.carrying),
      radius: 1
    });
    const nearbyMales = male.neighbors({
      source: males().filter((a) => a !== male && a.adult),
      radius: 1
    });
    if (eligibleFemales.length === 1 && nearbyMales.length === 0)
      male.partner = random.sample(eligibleFemales)[0];
    if (!male.partner)
      return;
    if (random.number() < settings.matingChance) {
      const partner = male.partner;
      partner.partner = male;
      partner.carrying = true;
      partner.numOfExes++;
      partner.tempMaleChildChance = (partner.maleChildChance + male.maleChildChance) / 2;
      male.numOfExes++;
    }
    male.partner = null;
  }
  function reproduce(female) {
    if (!female.carrying)
      return;
    if (female.gestation !== settings.gestationPeriod) {
      female.gestation++;
      return;
    }
    female.gestation = 0;
    female.carrying = false;
    const litter = random.number({
      min: 0,
      max: settings.maximumLitterSize,
      integer: true
    }) + 1;
    for (let n = 0;n < litter; n++) {
      const sex = random.number() < female.tempMaleChildChance ? "male" : "female";
      makeIndividual(sex, female);
    }
    if (female.partner?.alive)
      female.partner.numOfChildren += litter;
    female.numOfChildren += litter;
    female.partner = null;
  }
  function record() {
    history.push({
      tick: world.tick.value,
      males: males().length,
      females: females().length,
      pregnant: females().filter((a) => a.carrying).length,
      nonPregnant: females().filter((a) => !a.carrying).length,
      matingRatio: males().length && females().length && matingSuccess("female") !== 0 ? Math.round(matingSuccess("male") / matingSuccess("female") * 1000) / 1000 : null,
      chance: stats.describe(population().map((a) => a.maleChildChance)).mean ?? 0
    });
    if (history.length > 1001)
      history.splice(1, 1);
  }
  function advance(steps = 1) {
    stepCount(steps);
    for (let n = 0;n < steps; n++) {
      if (!population().length)
        break;
      for (const a of random.sample(population(), {
        count: population().length,
        compatibility: "legacy-shuffle"
      }))
        checkIfDead(a);
      for (const a of random.sample(males(), {
        count: males().length,
        compatibility: "legacy-shuffle"
      })) {
        move(a);
        if (a.age > adultAge)
          a.adult = true;
      }
      for (const a of random.sample(males().filter((a) => a.adult), {
        count: males().filter((a) => a.adult).length,
        compatibility: "legacy-shuffle"
      }))
        searchForAnAdultPartner(a);
      for (const a of random.sample(females(), {
        count: females().length,
        compatibility: "legacy-shuffle"
      })) {
        if (!a.carrying)
          move(a);
        if (a.age > adultAge)
          a.adult = true;
      }
      const fertile = females().filter((a) => a.adult);
      for (const a of random.sample(fertile, {
        count: fertile.length,
        compatibility: "legacy-shuffle"
      }))
        reproduce(a);
      adultSexRatioHistory.push(adultSexRatio(population()));
      world.tick.advance();
      record();
    }
  }
  function matingSuccess(sex) {
    const mean = stats.describe(population().filter((a) => a.sex === sex).map((a) => a.numOfExes)).mean;
    if (mean === undefined)
      throw new RangeError("MEAN expected a nonempty list (source mating-success reporter).");
    return Math.round(mean * 100) / 100;
  }
  function read() {
    const project = (a) => ({
      id: a.id,
      x: a.x,
      y: a.y,
      heading: a.heading,
      sex: a.sex,
      age: a.age,
      longevity: a.longevity,
      adult: a.adult,
      maleChildChance: a.maleChildChance,
      carrying: a.carrying,
      gestation: a.gestation,
      tempMaleChildChance: a.tempMaleChildChance,
      partner: a.partner?.id ?? null,
      numOfExes: a.numOfExes,
      numOfChildren: a.numOfChildren
    });
    const running = adultSexRatioHistory.length > 1000 ? stats.describe(adultSexRatioHistory.slice(-1000), { sample: true }) : undefined;
    return {
      sourceMarker,
      parameters: { ...settings },
      randomState: random.state,
      width: 33,
      height: 21,
      tick: world.tick.value,
      adultAge,
      done: !population().length,
      males: males().map(project),
      females: females().map(project),
      adultSexRatio: adultSexRatio(population()),
      averageMaleChildChance: stats.describe(population().map((a) => a.maleChildChance)).mean ?? 0,
      maleMatingSuccess: males().length ? matingSuccess("male") : "NA",
      femaleMatingSuccess: females().length ? matingSuccess("female") : "NA",
      adultSexRatioHistory: [...adultSexRatioHistory],
      ageList: [...ageList],
      runningAverageAdultSexRatio: running ? Math.round(running.mean * 100) / 100 : "NA",
      runningSdAdultSexRatio: running ? Math.round(running.standardDeviation * 100) / 100 : "NA",
      history: history.map((p) => ({ ...p }))
    };
  }
  function setParameters(change) {
    settings = parameters(inputs, { ...settings, ...change });
  }
  setup();
  return {
    read,
    advance,
    setup,
    setParameters,
    makeIndividual,
    move,
    checkIfDead,
    searchForAnAdultPartner,
    reproduce,
    matingSuccess
  };
}
var model = {
  title: "Sex Ratio Equilibrium",
  inputs,
  create
};

// experiments/sex-ratio-equilibrium/ui.ts
var ui = defineUI(model, {
  setup: [
    { field: "seed" },
    { field: "initialPopulationSize", label: "Initial population" },
    { field: "initialAdultSexRatio", label: "Initial male percentage" },
    {
      field: "initialAverageMaleChildChance",
      label: "Initial male-child chance"
    }
  ],
  live: [
    "meanLongevity",
    "gestationPeriod",
    "maximumLitterSize",
    "matingChance"
  ].map((field) => ({
    field,
    value: (s) => s.parameters[field],
    set: (m, v) => m.setParameters({ [field]: Number(v) })
  })),
  source: {
    url: "https://www.netlogoweb.org/launch#https://www.netlogoweb.org/assets/modelslib/Sample%20Models/Biology/Evolution/Sex%20Ratio%20Equilibrium.nlogox",
    label: "NetLogo original · Wilensky · CC BY-NC-SA 3.0"
  },
  complete: (s) => s.done,
  monitors: [
    { label: "Tick", value: (s) => s.tick },
    { label: "Adult sex ratio (%)", value: (s) => s.adultSexRatio },
    { label: "Male-child chance", value: (s) => s.averageMaleChildChance },
    { label: "Running average", value: (s) => s.runningAverageAdultSexRatio },
    { label: "Running SD", value: (s) => s.runningSdAdultSexRatio },
    { label: "Male mating success", value: (s) => s.maleMatingSuccess },
    { label: "Female mating success", value: (s) => s.femaleMatingSuccess }
  ],
  views: [
    {
      type: "spatial",
      label: "Population",
      data: (s) => ({
        width: s.width,
        height: s.height,
        agents: [...s.males, ...s.females].map((a) => ({
          ...a,
          color: a.sex === "male" ? "#3bb34b" : a.carrying ? "#f6a130" : "#428bd0",
          size: 7
        }))
      })
    },
    {
      type: "line",
      label: "Population by sex",
      series: (s) => [
        {
          label: "Males",
          color: "#3bb34b",
          points: s.history.map((p) => ({ x: p.tick, y: p.males }))
        },
        {
          label: "Females",
          color: "#428bd0",
          points: s.history.map((p) => ({ x: p.tick, y: p.females }))
        },
        {
          label: "Carrying",
          color: "#f6a130",
          points: s.history.map((p) => ({ x: p.tick, y: p.pregnant }))
        },
        {
          label: "Not carrying",
          color: "#5555a0",
          points: s.history.map((p) => ({ x: p.tick, y: p.nonPregnant }))
        }
      ]
    },
    {
      type: "line",
      label: "Mating success ratio (male to female)",
      series: (s) => [
        {
          label: "Ratio",
          points: s.history.filter((p) => p.matingRatio !== null).map((p) => ({ x: p.tick, y: p.matingRatio }))
        }
      ]
    },
    {
      type: "line",
      label: "Adult sex ratio",
      series: (s) => [
        {
          label: "Male percentage",
          points: s.adultSexRatioHistory.map((y, x) => ({ x: x + 1, y }))
        }
      ]
    },
    {
      type: "line",
      label: "Average male-child chance",
      series: (s) => [
        {
          label: "Chance",
          points: s.history.map((p) => ({ x: p.tick, y: p.chance }))
        }
      ]
    },
    {
      type: "inspector",
      label: "Selected individual",
      value: (s, id) => {
        const a = [...s.males, ...s.females].find((a) => a.id === id);
        return a ? {
          sex: a.sex,
          age: a.age,
          longevity: a.longevity,
          adult: a.adult,
          maleChildChance: a.maleChildChance,
          carrying: a.carrying,
          gestation: a.gestation,
          partners: a.numOfExes,
          children: a.numOfChildren
        } : undefined;
      }
    }
  ]
});
export {
  ui
};
