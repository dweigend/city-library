import {
  defineUI,
  Agent,
  Random,
  World,
  stats,
  parameters,
  stepCount
} from "./app-shg8ggtp.js";

// experiments/baldwin-effect/model.ts
var sourceMarker = "B08-baldwin-effect-native-composition-v1";
function fitnessOf(phenotype, target, smoothness, geneLength = target.length) {
  if (phenotype.length !== target.length || !target.length)
    throw new RangeError("Phenotype and target must have equal positive lengths.");
  const difference = phenotype.filter((a, i) => a !== target[i]).length;
  const fitness = (geneLength - difference) / geneLength;
  return fitness >= 1 - smoothness ? fitness : 0;
}
var inputs = {
  seed: { kind: "number", default: 1, integer: true },
  numPop: { kind: "number", default: 200, min: 1, max: 500, integer: true },
  geneLength: { kind: "number", default: 30, min: 1, max: 100, integer: true },
  plasticity: { kind: "number", default: 0.5, min: 0, max: 1 },
  numTrials: { kind: "number", default: 20, min: 1, max: 100, integer: true },
  mutationRate: { kind: "number", default: 5, min: 0, max: 10 },
  smoothness: { kind: "number", default: 0.15, min: 0, max: 1 }
};
function create(options = {}) {
  let settings = parameters(inputs, options);
  const random = Random.add({ seed: settings.seed });
  const world = World.add({ random });
  let targetPhenotype = [];
  const history = [];
  const population = (breed) => world.agents.filter((a) => a.breed === breed);
  function produceGene() {
    return Array.from({ length: settings.geneLength }, () => random.number() < settings.plasticity ? "x" : random.sample([0, 1])[0]);
  }
  function initPhenotype(gene) {
    return gene.map((a) => a === "x" ? random.sample([0, 1])[0] : a);
  }
  function plasticityFrequency(a) {
    return a.genotype.filter((g) => g === "x").length / a.genotype.length;
  }
  function correctAlleleFrequency(a) {
    return a.genotype.filter((g, i) => g === targetPhenotype[i]).length / a.genotype.length;
  }
  function updatePosition(a) {
    const offset = a.breed === "nonLearner" ? -28 : a.breed === "smartLearner" ? 28 : 0;
    a.move({
      to: {
        x: offset + (correctAlleleFrequency(a) - 0.5) * 20,
        y: a.fitness * 100 - 50
      }
    });
  }
  function meanPlasticity(breed) {
    const group = population(breed);
    return group.length ? group.reduce((sum, a) => sum + plasticityFrequency(a) * 100, 0) / group.length : 0;
  }
  function record() {
    history.push({
      tick: world.tick.value,
      nonLearners: population("nonLearner").length,
      randomLearners: population("randomLearner").length,
      smartLearners: population("smartLearner").length,
      nonPlasticity: meanPlasticity("nonLearner"),
      randomPlasticity: meanPlasticity("randomLearner"),
      smartPlasticity: meanPlasticity("smartLearner"),
      nonCorrect: stats.describe(population("nonLearner").map((a) => correctAlleleFrequency(a) * 100)).mean,
      randomCorrect: stats.describe(population("randomLearner").map((a) => correctAlleleFrequency(a) * 100)).mean,
      smartCorrect: stats.describe(population("smartLearner").map((a) => correctAlleleFrequency(a) * 100)).mean,
      nonFitness: stats.describe(population("nonLearner").map((a) => a.fitness)).mean,
      randomFitness: stats.describe(population("randomLearner").map((a) => a.fitness)).mean,
      smartFitness: stats.describe(population("smartLearner").map((a) => a.fitness)).mean
    });
    if (history.length > 1001)
      history.splice(1, 1);
  }
  function setup() {
    world.delete(world.agents);
    world.tick.reset();
    random.reseed(settings.seed);
    history.length = 0;
    targetPhenotype = Array.from({ length: settings.geneLength }, () => random.sample([0, 1])[0]);
    for (const breed of [
      "randomLearner",
      "nonLearner",
      "smartLearner"
    ]) {
      for (let i = 0;i < settings.numPop; i++) {
        const produced = produceGene();
        const genotype = breed === "nonLearner" ? initPhenotype(produced) : produced;
        const phenotype = breed === "nonLearner" ? [...genotype] : initPhenotype(genotype);
        const a = Agent.add({
          breed,
          genotype,
          phenotype,
          fitness: fitnessOf(phenotype, targetPhenotype, settings.smoothness, settings.geneLength)
        });
        world.add(a);
        updatePosition(a);
      }
    }
    record();
  }
  function randomLearn(a) {
    a.fitness = fitnessOf(a.phenotype, targetPhenotype, settings.smoothness, settings.geneLength);
    let total = 0;
    for (let trial = 0;trial < settings.numTrials; trial++) {
      const next = initPhenotype(a.genotype);
      const fitness = fitnessOf(next, targetPhenotype, settings.smoothness, settings.geneLength);
      if (fitness > a.fitness) {
        a.phenotype = next;
        a.fitness = fitness;
      }
      total += a.fitness;
    }
    a.fitness = total / settings.numTrials;
    updatePosition(a);
  }
  function smartLearn(a) {
    a.fitness = fitnessOf(a.phenotype, targetPhenotype, settings.smoothness, settings.geneLength);
    let total = 0;
    for (let trial = 0;trial < settings.numTrials; trial++) {
      const next = a.genotype.map((gene, i) => gene === "x" ? random.number() < a.fitness ? a.phenotype[i] : random.sample([0, 1])[0] : gene);
      const fitness = fitnessOf(next, targetPhenotype, settings.smoothness, settings.geneLength);
      if (fitness > a.fitness) {
        a.phenotype = next;
        a.fitness = fitness;
      }
      total += a.fitness;
    }
    a.fitness = total / settings.numTrials;
    updatePosition(a);
  }
  function select(breed) {
    const group = population(breed);
    const shuffled = random.sample(group, {
      count: group.length,
      compatibility: "legacy-shuffle"
    });
    shuffled.sort((a, b) => a.fitness - b.fitness);
    for (const a of shuffled.slice(0, Math.ceil(settings.numPop * 0.2)))
      a.delete();
  }
  function reproduce(breed) {
    for (let i = 0;i < Math.floor(settings.numPop * 0.2); i++) {
      const group = population(breed);
      const tournament = random.sample(group, {
        count: Math.floor(settings.numPop * 0.3)
      });
      if (tournament.length < 2)
        throw new RangeError("Source weighted-n-of requires two tournament members.");
      const selected = random.sample(tournament, {
        count: 2,
        weight: (a) => a.fitness
      });
      if (selected.length < 2) {
        const remaining = tournament.filter((a) => !selected.includes(a));
        selected.push(...random.sample(remaining, { count: 2 - selected.length }));
      }
      const [left, right] = selected;
      const genotype = left.genotype.map((gene, j) => random.sample([gene, right.genotype[j]])[0]);
      const mutated = genotype.map((gene) => random.number() > settings.mutationRate / 1000 ? gene : random.sample(breed === "nonLearner" ? [0, 1] : [0, 1, "x"])[0]);
      const parent = random.sample(selected)[0];
      const child = parent.copy();
      world.add(child);
      child.genotype = mutated;
      child.phenotype = initPhenotype(mutated);
      updatePosition(child);
    }
  }
  function advance(count = 1) {
    stepCount(count);
    for (let i = 0;i < count; i++) {
      for (const breed of [
        "randomLearner",
        "smartLearner",
        "nonLearner"
      ]) {
        const group = population(breed);
        for (const a of random.sample(group, {
          count: group.length,
          compatibility: "legacy-shuffle"
        })) {
          if (breed === "randomLearner")
            randomLearn(a);
          else if (breed === "smartLearner")
            smartLearn(a);
          else {
            a.fitness = fitnessOf(a.phenotype, targetPhenotype, settings.smoothness, settings.geneLength);
            updatePosition(a);
          }
        }
        select(breed);
        reproduce(breed);
      }
      world.tick.advance();
      record();
    }
  }
  function read() {
    const snapshots = (breed) => population(breed).map((a) => ({
      id: a.id,
      x: a.x,
      y: a.y,
      originalY: a.y + 50,
      genotype: [...a.genotype],
      phenotype: [...a.phenotype],
      fitness: a.fitness,
      plasticityFrequency: plasticityFrequency(a),
      correctAlleleFrequency: correctAlleleFrequency(a)
    }));
    return {
      sourceMarker,
      tick: world.tick.value,
      width: 81,
      height: 111,
      parameters: settings,
      targetPhenotype: [...targetPhenotype],
      nonLearners: snapshots("nonLearner"),
      randomLearners: snapshots("randomLearner"),
      smartLearners: snapshots("smartLearner"),
      history: history.map((p) => ({ ...p })),
      randomState: random.state
    };
  }
  setup();
  return {
    setup,
    advance,
    read,
    produceGene,
    initPhenotype,
    randomLearn,
    smartLearn,
    select,
    reproduce,
    setParameters(update) {
      settings = parameters(inputs, { ...settings, ...update });
    }
  };
}
var model = {
  title: "Baldwin Effect",
  inputs,
  create
};

// experiments/baldwin-effect/ui.ts
var ui = defineUI(model, {
  setup: [{ field: "seed" }],
  live: [
    "numPop",
    "geneLength",
    "plasticity",
    "numTrials",
    "mutationRate",
    "smoothness"
  ].map((field) => ({
    field,
    value: (s) => s.parameters[field],
    set: (m, value) => m.setParameters({ [field]: Number(value) })
  })),
  source: {
    url: "https://www.netlogoweb.org/launch#https://www.netlogoweb.org/assets/modelslib/Sample%20Models/Biology/Evolution/Baldwin%20Effect.nlogox",
    label: "NetLogo Baldwin Effect · Wilensky · CC BY-NC-SA 3.0"
  },
  monitors: [{ label: "Generation", value: (s) => s.tick }],
  views: [
    {
      type: "spatial",
      label: "Fitness and inherited matches",
      data: (s) => ({
        width: s.width,
        height: s.height,
        agents: [
          ...s.nonLearners.map((a) => ({ ...a, color: "#888888" })),
          ...s.randomLearners.map((a) => ({ ...a, color: "#d73027" })),
          ...s.smartLearners.map((a) => ({ ...a, color: "#4575b4" }))
        ].map((a) => ({ ...a, size: 5 }))
      })
    },
    {
      type: "line",
      label: "Plastic alleles (%)",
      series: (s) => ["nonPlasticity", "randomPlasticity", "smartPlasticity"].map((key) => ({
        label: key.startsWith("non") ? "Non-learners" : key.startsWith("random") ? "Random learners" : "Smart learners",
        color: key === "nonPlasticity" ? "#888888" : key === "randomPlasticity" ? "#d73027" : "#4575b4",
        points: s.history.map((p) => ({ x: p.tick, y: p[key] }))
      }))
    },
    {
      type: "line",
      label: "Correct inherited alleles (%)",
      series: (s) => ["nonCorrect", "randomCorrect", "smartCorrect"].map((key) => ({
        label: key.startsWith("non") ? "Non-learners" : key.startsWith("random") ? "Random learners" : "Smart learners",
        color: key === "nonCorrect" ? "#888888" : key === "randomCorrect" ? "#d73027" : "#4575b4",
        points: s.history.flatMap((p) => p[key] === undefined ? [] : [{ x: p.tick, y: p[key] }])
      }))
    },
    {
      type: "line",
      label: "Mean fitness",
      series: (s) => ["nonFitness", "randomFitness", "smartFitness"].map((key) => ({
        label: key.startsWith("non") ? "Non-learners" : key.startsWith("random") ? "Random learners" : "Smart learners",
        color: key === "nonFitness" ? "#888888" : key === "randomFitness" ? "#d73027" : "#4575b4",
        points: s.history.flatMap((p) => p[key] === undefined ? [] : [{ x: p.tick, y: p[key] }])
      }))
    },
    {
      type: "inspector",
      label: "Genotype and learned phenotype",
      value: (s, id) => {
        const a = [
          ...s.nonLearners,
          ...s.randomLearners,
          ...s.smartLearners
        ].find((a) => a.id === id);
        return a ? {
          genotype: a.genotype.join(""),
          phenotype: a.phenotype.join(""),
          fitness: a.fitness,
          plasticity: a.plasticityFrequency,
          correctAlleles: a.correctAlleleFrequency
        } : undefined;
      }
    }
  ]
});
export {
  ui
};
