import {
  defineUI,
  Agent,
  Random,
  World,
  Grid,
  geometry,
  parameters,
  stepCount
} from "./app-shg8ggtp.js";

// experiments/bacterial-infection/model.ts
var sourceMarker = "b08-bacterial-infection-source-composition-v1";
var dosingOptions = [
  "no, skip all dosing",
  "yes, skip no doses",
  "yes, but skip dose 2",
  "yes, but skip dose 3",
  "yes, but skip dose 4"
];
var inputs = {
  seed: {
    kind: "number",
    default: 1,
    min: -2147483648,
    max: 4294967295,
    integer: true
  },
  reproduce: { kind: "boolean", default: true },
  reproduceEvery: { kind: "number", default: 2, min: 0.5, max: 4, step: 0.5 },
  autoDoseA: {
    kind: "choice",
    default: "yes, but skip dose 4",
    options: dosingOptions
  },
  autoDoseB: {
    kind: "choice",
    default: "yes, but skip dose 4",
    options: dosingOptions
  },
  aDosage: { kind: "number", default: 50, min: 50, max: 200, step: 50 },
  bDosage: { kind: "number", default: 50, min: 50, max: 200, step: 50 },
  doseAEvery: { kind: "number", default: 4, min: 4, max: 24, step: 2 },
  doseBEvery: { kind: "number", default: 4, min: 4, max: 24, step: 4 },
  init3PoresA: { kind: "number", default: 4, min: 0, max: 16, integer: true },
  init4PoresA: { kind: "number", default: 4, min: 0, max: 16, integer: true },
  init5PoresA: { kind: "number", default: 4, min: 0, max: 16, integer: true },
  init6PoresA: { kind: "number", default: 4, min: 0, max: 16, integer: true },
  init3PoresB: { kind: "number", default: 4, min: 0, max: 16, integer: true },
  init4PoresB: { kind: "number", default: 4, min: 0, max: 16, integer: true },
  init5PoresB: { kind: "number", default: 4, min: 0, max: 16, integer: true },
  init6PoresB: { kind: "number", default: 4, min: 0, max: 16, integer: true }
};
function giveDose(tick, doseEvery, wipedOut, autoDose, dosesGiven) {
  return tick % (doseEvery * 60) === 0 && !wipedOut && (autoDose === "yes, skip no doses" || autoDose === "yes, but skip dose 2" && dosesGiven !== 1 || autoDose === "yes, but skip dose 3" && dosesGiven !== 2 || autoDose === "yes, but skip dose 4" && dosesGiven !== 3);
}
function create(options = {}) {
  let settings = parameters(inputs, options);
  const random = Random.add({ seed: settings.seed });
  const space = { x: 49, y: 21, boundary: "wrap" };
  const world = World.add(space, { random });
  const grid = Grid.add(space, {
    state: {
      region: null,
      portType: "none",
      myBacteria: null
    }
  });
  world.add(grid);
  const bacteria = () => world.agents.filter((a) => a.breed === "bacteria");
  const antibiotics = () => world.agents.filter((a) => a.breed === "antibiotic");
  let dosesGivenToA = 0;
  let dosesGivenToB = 0;
  let aWipedOut = false;
  let bWipedOut = false;
  let feverFactor = false;
  const antibioticFlowRate = 0.2;
  const history = [];
  const regionAt = (agent) => grid.fieldAt(agent).region;
  function setupRegions() {
    for (const field of grid.fields) {
      field.region = field.x > -24 && field.x < -1 ? "A" : field.x < 24 && field.x > 1 ? "B" : null;
      field.myBacteria = null;
      field.portType = ![-24, -1, 1, 24].includes(field.x) ? field.y === 10 ? "input" : field.y === -10 ? "output" : "none" : "none";
    }
  }
  function makeBacteria(count, variation, region) {
    if (!Number.isSafeInteger(count) || count < 0 || ![3, 4, 5, 6].includes(variation))
      throw new RangeError("Invalid bacteria count or variation.");
    const created = [];
    for (let n = 0;n < count; n++) {
      const target = random.sample(grid.fields.filter((f) => f.region === region && !f.myBacteria?.alive))[0];
      if (!target)
        throw new RangeError("No available patch in the source region.");
      const agent = Agent.add({
        breed: "bacteria",
        variation,
        age: settings.reproduceEvery * 60,
        target
      }, {
        position: target,
        orientation: {
          heading: random.number({ min: 0, max: 360, integer: true })
        }
      });
      world.add(agent);
      target.myBacteria = agent;
      created.push(agent);
    }
    return created;
  }
  function setup() {
    world.delete(world.agents);
    world.tick.reset();
    dosesGivenToA = 0;
    dosesGivenToB = 0;
    aWipedOut = false;
    bWipedOut = false;
    feverFactor = false;
    history.length = 0;
    setupRegions();
    for (const region of ["A", "B"]) {
      for (const variation of [3, 4, 5, 6]) {
        const key = `init${variation}Pores${region}`;
        makeBacteria(settings[key], variation, region);
      }
    }
    record();
  }
  function checkBounceOffWalls(agent) {
    const patch = grid.fieldAt(agent);
    if (![-23, -2, 2, 23].includes(patch.x))
      return;
    const direction = geometry.direction({ heading: agent.heading });
    const ahead = geometry.normalize({ x: agent.x + 0.5 * direction.x, y: agent.y + 0.5 * direction.y }, { space, endpoints: "half-open" });
    if ([-24, -1, 1, 24].includes(grid.fieldAt(ahead).x)) {
      agent.move(-antibioticFlowRate);
      agent.rotate(-2 * agent.heading);
    }
  }
  function canReproduce(agent, totalCount) {
    const fever = totalCount > 50 && feverFactor ? 1 + 2 * ((totalCount - 50) / 75) : 1;
    return agent.age >= settings.reproduceEvery * 60 * fever && agent.neighbors({
      source: bacteria().filter((a) => a !== agent),
      radius: 0.75
    }).length === 0 && agent.target === grid.fieldAt(agent);
  }
  function reproduceBacteriaIntoAvailableSpace() {
    const total = bacteria().length;
    const eligible = bacteria().filter((a) => canReproduce(a, total));
    if (!settings.reproduce)
      return;
    for (const agent of random.sample(eligible, {
      count: eligible.length,
      compatibility: "legacy-shuffle"
    })) {
      const available = grid.neighbors(grid.fieldAt(agent), { neighborhood: "moore" }).filter((f) => f.region === regionAt(agent) && !f.myBacteria?.alive);
      if (!available.length)
        continue;
      const target = random.sample(available)[0];
      const child = agent.copy();
      child.target = target;
      world.add(child);
      target.myBacteria = agent;
    }
  }
  function moveBacteria(agent) {
    if (!agent.target)
      throw new TypeError("Bacteria has no source target patch.");
    if (agent.distanceTo(agent.target) > 0.2) {
      agent.rotate({ towards: agent.target });
      agent.move(0.015);
      agent.age = 0;
    }
    checkBounceOffWalls(agent);
    agent.age++;
  }
  function bacteriaDeath(agent) {
    agent.delete();
  }
  function doseRegion(region, dosage) {
    if (region !== "A" && region !== "B")
      throw new RangeError("Unknown region.");
    const amount = dosage ?? (region === "A" ? settings.aDosage : settings.bDosage);
    if (!Number.isSafeInteger(amount) || amount < 0 || amount > 1e4)
      throw new RangeError("Invalid dose.");
    const inputs = grid.fields.filter((f) => f.region === region && f.portType === "input");
    for (let n = 0;n < amount; n++) {
      const field = random.sample(inputs)[0];
      const agent = Agent.add({ breed: "antibiotic" }, {
        position: {
          x: field.x - 0.5 + random.number(),
          y: field.y - 0.5 + random.number()
        },
        orientation: {
          heading: 180 + random.number({ min: 0, max: 35, integer: true }) - random.number({ min: 0, max: 35, integer: true })
        }
      });
      world.add(agent);
    }
    if (region === "A")
      dosesGivenToA++;
    else
      dosesGivenToB++;
  }
  function killThisBacteria(agent) {
    return random.number({ min: 0, max: 100, integer: true }) < agent.variation * 10;
  }
  function checkAntibioticInteraction(agent) {
    const samePatch = grid.agentsAt(grid.fieldAt(agent), {
      source: bacteria()
    });
    if (samePatch.length) {
      const target = random.sample(samePatch)[0];
      if (killThisBacteria(target))
        bacteriaDeath(target);
      agent.delete();
      return;
    }
    if (grid.fieldAt(agent).portType === "output" && random.number({
      min: 0,
      max: Math.round(2 / antibioticFlowRate),
      integer: true
    }) === 0)
      agent.delete();
  }
  function moveAntibiotics() {
    for (const agent of random.sample(antibiotics(), {
      count: antibiotics().length,
      compatibility: "legacy-shuffle"
    })) {
      agent.move(antibioticFlowRate);
      checkBounceOffWalls(agent);
      checkAntibioticInteraction(agent);
    }
  }
  function autoDose() {
    if (giveDose(world.tick.value, settings.doseAEvery, aWipedOut, settings.autoDoseA, dosesGivenToA))
      doseRegion("A");
    if (giveDose(world.tick.value, settings.doseBEvery, bWipedOut, settings.autoDoseB, dosesGivenToB))
      doseRegion("B");
  }
  function doseEachRegion() {
    if (!bacteria().some((a) => regionAt(a) === "A"))
      aWipedOut = true;
    if (!bacteria().some((a) => regionAt(a) === "B"))
      bWipedOut = true;
    autoDose();
  }
  function counts(region) {
    return [3, 4, 5, 6].map((v) => bacteria().filter((a) => regionAt(a) === region && a.variation === v).length);
  }
  function record() {
    history.push({ tick: world.tick.value, a: counts("A"), b: counts("B") });
    if (history.length > 1001)
      history.splice(1, 1);
  }
  function advance(steps = 1) {
    stepCount(steps);
    for (let n = 0;n < steps; n++) {
      reproduceBacteriaIntoAvailableSpace();
      for (const agent of random.sample(bacteria(), {
        count: bacteria().length,
        compatibility: "legacy-shuffle"
      }))
        moveBacteria(agent);
      moveAntibiotics();
      doseEachRegion();
      world.tick.advance();
      record();
    }
  }
  function read() {
    return {
      sourceMarker,
      parameters: { ...settings },
      randomState: random.state,
      width: 49,
      height: 21,
      tick: world.tick.value,
      minutes: world.tick.value,
      hours: Math.floor(world.tick.value / 60),
      days: Math.floor(Math.floor(world.tick.value / 60) / 2.4) / 10,
      antibioticFlowRate,
      feverFactor,
      dosesGivenToA,
      dosesGivenToB,
      aWipedOut,
      bWipedOut,
      bacteriaCountsRegionA: counts("A"),
      bacteriaCountsRegionB: counts("B"),
      bacteria: bacteria().map((a) => ({
        id: a.id,
        x: a.x,
        y: a.y,
        heading: a.heading,
        variation: a.variation,
        age: a.age,
        region: regionAt(a),
        targetX: a.target?.x ?? 0,
        targetY: a.target?.y ?? 0
      })),
      antibiotics: antibiotics().map((a) => ({
        id: a.id,
        x: a.x,
        y: a.y,
        heading: a.heading,
        region: regionAt(a)
      })),
      cells: grid.fields.map((f) => ({
        id: f.id,
        x: f.x,
        y: f.y,
        region: f.region,
        portType: f.portType,
        owner: f.myBacteria?.alive ? f.myBacteria.id : null
      })),
      history: history.map((p) => ({ ...p, a: [...p.a], b: [...p.b] }))
    };
  }
  function setParameters(change) {
    settings = parameters(inputs, { ...settings, ...change });
  }
  function setFeverFactor(value) {
    if (typeof value !== "boolean")
      throw new TypeError("Fever factor must be boolean.");
    feverFactor = value;
  }
  setup();
  return {
    read,
    advance,
    setup,
    setParameters,
    setFeverFactor,
    makeBacteria,
    canReproduce,
    reproduceBacteriaIntoAvailableSpace,
    moveBacteria,
    bacteriaDeath,
    doseRegion,
    autoDose,
    doseEachRegion,
    checkBounceOffWalls,
    killThisBacteria,
    checkAntibioticInteraction,
    moveAntibiotics
  };
}
var model = {
  title: "Bacterial Infection",
  inputs,
  create
};

// experiments/bacterial-infection/ui.ts
var ui = defineUI(model, {
  setup: [
    "seed",
    "init3PoresA",
    "init4PoresA",
    "init5PoresA",
    "init6PoresA",
    "init3PoresB",
    "init4PoresB",
    "init5PoresB",
    "init6PoresB"
  ].map((field) => ({ field })),
  live: [
    "reproduce",
    "reproduceEvery",
    "autoDoseA",
    "autoDoseB",
    "aDosage",
    "bDosage",
    "doseAEvery",
    "doseBEvery"
  ].map((field) => ({
    field,
    value: (s) => s.parameters[field],
    set: (m, v) => m.setParameters({
      [field]: field === "reproduce" ? Boolean(v) : field === "autoDoseA" || field === "autoDoseB" ? String(v) : Number(v)
    })
  })),
  actions: [
    { label: "Manual dose A", run: (m) => m.doseRegion("A") },
    { label: "Manual dose B", run: (m) => m.doseRegion("B") }
  ],
  source: {
    url: "https://www.netlogoweb.org/launch#https://www.netlogoweb.org/assets/modelslib/Sample%20Models/Biology/Evolution/Bacterial%20Infection.nlogox",
    label: "NetLogo original · Wilensky · CC BY-NC-SA 3.0"
  },
  monitors: [
    { label: "Minutes", value: (s) => s.minutes },
    { label: "Hours", value: (s) => s.hours },
    { label: "Days", value: (s) => s.days },
    { label: "Doses A", value: (s) => s.dosesGivenToA },
    { label: "Doses B", value: (s) => s.dosesGivenToB }
  ],
  views: [
    {
      type: "spatial",
      label: "Patients A and B",
      data: (s) => ({
        width: s.width,
        height: s.height,
        cells: s.cells.map((c) => ({
          ...c,
          color: c.x === 0 ? "#999999" : c.portType === "input" ? "#9b2121" : c.portType === "output" ? "#9b8d21" : c.region ? "#ffd7d7" : "#4a4a4a"
        })),
        agents: [
          ...s.bacteria.map((a) => ({
            ...a,
            color: ["#a536c7", "#389b39", "#8b603f", "#ce3030"][a.variation - 3],
            size: 10
          })),
          ...s.antibiotics.map((a) => ({ ...a, color: "#dd2020", size: 4 }))
        ]
      })
    },
    ...["A", "B"].map((region) => ({
      type: "bar",
      label: `Patient ${region} pore counts`,
      series: (s) => [
        {
          label: region,
          points: (region === "A" ? s.bacteriaCountsRegionA : s.bacteriaCountsRegionB).map((y, i) => ({ x: i + 3, y }))
        }
      ]
    })),
    ...["A", "B"].map((region) => ({
      type: "line",
      label: `Population in ${region}`,
      series: (s) => [3, 4, 5, 6].map((v, i) => ({
        label: `${v} pores`,
        color: ["#a536c7", "#389b39", "#8b603f", "#ce3030"][i],
        points: s.history.map((p) => ({
          x: p.tick,
          y: (region === "A" ? p.a : p.b)[i]
        }))
      }))
    })),
    {
      type: "inspector",
      label: "Selected bacterium",
      value: (s, id) => {
        const a = s.bacteria.find((a) => a.id === id);
        return a ? {
          variation: a.variation,
          age: a.age,
          region: a.region ?? "",
          targetX: a.targetX,
          targetY: a.targetY
        } : undefined;
      }
    }
  ]
});
export {
  ui
};
