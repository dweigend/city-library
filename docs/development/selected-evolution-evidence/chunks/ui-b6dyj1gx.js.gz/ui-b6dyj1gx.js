import {
  defineUI,
  Agent,
  Random,
  World,
  Grid,
  parameters,
  stepCount
} from "./app-shg8ggtp.js";

// experiments/mendelian-inheritance/model.ts
var sourceMarker = "b08-mendelian-inheritance-source-composition-v1";
var inputs = {
  seed: {
    kind: "number",
    default: 1,
    integer: true,
    min: -2147483648,
    max: 4294967295
  },
  maleGenotype: { kind: "choice", default: "Aa", options: ["AA", "Aa", "aa"] },
  femaleGenotype: {
    kind: "choice",
    default: "Aa",
    options: ["AA", "Aa", "aa"]
  },
  numberOfOffspring: {
    kind: "number",
    default: 6,
    min: 0,
    max: 10,
    integer: true
  }
};
function create(options = {}) {
  let settings = parameters(inputs, options);
  const random = Random.add({ seed: settings.seed });
  const space = { x: 33, y: 33, boundary: "hard" };
  const world = World.add(space, { random });
  const grid = Grid.add(space);
  world.add(grid);
  let parent1;
  let parent2;
  let trialNumber = 0;
  let numberOfDarkOffspring = 0;
  let numberOfLightOffspring = 0;
  let previousNumberOfDarkOffspring = 0;
  let previousNumberOfLightOffspring = 0;
  let selectedGenotype = null;
  let message = "";
  const mice = () => world.agents;
  function setup() {
    world.delete(mice());
    world.tick.reset();
    trialNumber = 0;
    numberOfDarkOffspring = 0;
    numberOfLightOffspring = 0;
    previousNumberOfDarkOffspring = 0;
    previousNumberOfLightOffspring = 0;
    selectedGenotype = null;
    message = "";
    parent1 = Agent.add({
      genotype: settings.maleGenotype,
      generation: "",
      sex: "male"
    }, { position: { x: -7, y: 10 } });
    parent2 = Agent.add({
      genotype: settings.femaleGenotype,
      generation: "",
      sex: "female"
    }, { position: { x: 7, y: 10 } });
    world.add([parent1, parent2]);
  }
  function setLocation(mouse) {
    do {
      mouse.move({
        to: {
          x: random.number({ min: 0, max: 28, integer: true }) - 14,
          y: random.number({ min: 0, max: 16, integer: true }) - 14
        }
      });
    } while (mouse.neighbors({
      radius: 2,
      source: mice().filter((other) => other !== mouse)
    }).length > 0);
  }
  function makeF1Generation() {
    if (mice().length > 50) {
      message = "Too much population! Press 'setup' to start a new experiment.";
      return;
    }
    message = "";
    for (let n = 0;n < settings.numberOfOffspring; n++) {
      const maleGamete = random.sample([...parent1.genotype])[0];
      const femaleGamete = random.sample([...parent2.genotype])[0];
      const mouse = Agent.add({
        genotype: maleGamete + femaleGamete,
        generation: "F1",
        sex: ""
      });
      world.add(mouse);
      setLocation(mouse);
    }
    trialNumber++;
    numberOfDarkOffspring = previousNumberOfDarkOffspring + mice().filter((a) => a.generation === "F1" && a.genotype.includes("A")).length;
    numberOfLightOffspring = previousNumberOfLightOffspring + mice().filter((a) => a.generation === "F1" && !a.genotype.includes("A")).length;
    world.tick.advance();
  }
  function clearF1Generation() {
    previousNumberOfDarkOffspring = numberOfDarkOffspring;
    previousNumberOfLightOffspring = numberOfLightOffspring;
    world.delete(mice().filter((a) => a.y <= 1));
  }
  function displayGenotype(id) {
    const mouse = mice().find((a) => a.id === id);
    selectedGenotype = mouse?.genotype ?? null;
    message = mouse ? "" : "Click on a mouse to know its genotype.";
    return selectedGenotype;
  }
  function read() {
    const both = numberOfDarkOffspring > 0 && numberOfLightOffspring > 0;
    return {
      sourceMarker,
      parameters: { ...settings },
      randomState: random.state,
      width: 33,
      height: 33,
      tick: world.tick.value,
      trialNumber,
      mice: mice().map((a) => ({
        id: a.id,
        x: a.x,
        y: a.y,
        genotype: a.genotype,
        generation: a.generation,
        sex: a.sex,
        dark: a.genotype.includes("A")
      })),
      numberOfDarkOffspring,
      numberOfLightOffspring,
      previousNumberOfDarkOffspring,
      previousNumberOfLightOffspring,
      darkRatioValue: both ? numberOfDarkOffspring / numberOfLightOffspring : "N/A",
      lightRatioValue: both ? "1" : "N/A",
      selectedGenotype,
      message,
      done: mice().length > 50
    };
  }
  function setParameters(change) {
    settings = parameters(inputs, { ...settings, ...change });
  }
  function advance(steps = 1) {
    stepCount(steps);
    for (let n = 0;n < steps; n++) {
      if (mice().length > 50)
        break;
      makeF1Generation();
    }
  }
  setup();
  return {
    read,
    advance,
    setup,
    setParameters,
    makeF1Generation,
    clearF1Generation,
    displayGenotype,
    setLocation
  };
}
var model = {
  title: "Mendelian Inheritance",
  inputs,
  create
};

// experiments/mendelian-inheritance/ui.ts
var ui = defineUI(model, {
  setup: [
    { field: "seed" },
    { field: "maleGenotype", label: "Male parent genotype" },
    { field: "femaleGenotype", label: "Female parent genotype" }
  ],
  live: [
    {
      field: "numberOfOffspring",
      label: "Offspring per trial",
      value: (s) => s.parameters.numberOfOffspring,
      set: (m, v) => m.setParameters({ numberOfOffspring: Number(v) })
    }
  ],
  actions: [
    { label: "Make F1 generation", run: (m) => m.makeF1Generation() },
    { label: "Clear F1 generation", run: (m) => m.clearF1Generation() },
    {
      label: "Read genotype",
      run: (m, selected) => {
        m.displayGenotype(selected);
      }
    }
  ],
  source: {
    url: "https://www.netlogoweb.org/launch#https://www.netlogoweb.org/assets/modelslib/Curricular%20Models/CT-STEM/Mendelian%20Inheritance.nlogox",
    label: "NetLogo original · Wilensky · CC BY-NC-SA 3.0"
  },
  complete: (s) => s.done,
  monitors: [
    { label: "Trial", value: (s) => s.trialNumber },
    { label: "Dark offspring", value: (s) => s.numberOfDarkOffspring },
    { label: "Light offspring", value: (s) => s.numberOfLightOffspring },
    { label: "Dark ratio", value: (s) => s.darkRatioValue },
    { label: "Light ratio", value: (s) => s.lightRatioValue },
    { label: "Genotype", value: (s) => s.selectedGenotype ?? "Select a mouse" },
    { label: "Message", value: (s) => s.message }
  ],
  views: [
    {
      type: "spatial",
      label: "Parents and F1 offspring",
      data: (s) => ({
        width: s.width,
        height: s.height,
        agents: s.mice.map((a) => ({
          ...a,
          label: a.sex,
          color: a.dark ? "#777777" : "#ffffff",
          size: a.generation === "F1" ? 16 : 25
        }))
      })
    },
    {
      type: "inspector",
      label: "Mouse genotype",
      value: (s, id) => {
        const a = s.mice.find((a) => a.id === id);
        return a ? {
          genotype: a.genotype,
          generation: a.generation || "parent",
          phenotype: a.dark ? "dark" : "light"
        } : undefined;
      }
    }
  ]
});
export {
  ui
};
